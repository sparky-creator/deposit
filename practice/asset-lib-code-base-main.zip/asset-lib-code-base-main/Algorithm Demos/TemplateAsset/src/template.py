# Copyright (C) 2021-2023 IBM Quantum
#
# This code is categorized as "existing" IBM asset
# as a part of Quantum Acceleration contract.



# The code starts here