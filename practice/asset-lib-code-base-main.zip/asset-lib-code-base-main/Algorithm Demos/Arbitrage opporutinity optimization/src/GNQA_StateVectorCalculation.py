# Copyright (C) 2021-2023 IBM Quantum
#
# This code is categorized as "existing" IBM asset
# as a part of Quantum Acceleration contract.



from qiskit import QuantumCircuit
from qiskit.opflow.state_fns import CircuitStateFn
from qiskit_optimization.algorithms import OptimizationResult, OptimizationResultStatus

import numpy as np 
from math import pi
from scipy.sparse import coo_matrix
import pandas as pd


class GNQA_functions():
    
    def __init__(self, qubo):
        self.H, self.offset = qubo.to_ising()
        self.N = self.H.num_qubits

        self.theta = np.full(self.N, pi/4)
        self.x = None
        self.filtered_H = None
        self.objval = None
        self.fval = None
        self.result_as_df = None
        
        self.qubo = qubo
        Q_info = self.qubo.objective.quadratic.coefficients.copy()
        l_diag = self.qubo.objective.linear
        n_qubo = self.qubo.get_num_binary_vars()
        for k in range(n_qubo):
            Q_info[k,k] += l_diag[k]
        self.Q = Q_info.tocoo()
        self.n_nonzero = len(self.Q.data)
        self.qubo_offset = self.qubo.objective.constant
        
    def eval_objective_function(self):
        X = np.cos(2*self.theta)
        val = 0
        for l in range(self.n_nonzero):
            j,k,q = self.Q.row[l], self.Q.col[l], self.Q.data[l]
            if j<k:
                d = q*(X[j]*X[k]-X[j]-X[k])
            else:
                d = -2*q*X[j]
            val += d    
        self.obj_val = val/4 + self.offset

    def indicator(self):
        self.x = (1/2)*(1 - np.cos(2*self.theta))
        self.x = np.where(self.x<0.5, 0, 1)
        self.fval = self.x @ self.Q @ self.x + self.qubo_offset

    def calculation_expectation(self, theta):
        circ = QuantumCircuit(self.N)
        for j in range(self.N):
            circ.ry(2*theta[j], j)
        phi = CircuitStateFn(circ)
        V = phi.to_matrix().real
        val = V@self.filtered_H@V.T
        return val

    def set_filtered_hamiltonian(self, filter_function, Omega, epsiron):
        M = 2**self.N
        H_mat = self.H.to_spmatrix().real
        H_data = np.array([H_mat[i,i] for i in range(M)])
        s_min, s_max = (1+epsiron)*np.min(H_data), (1+epsiron)*np.max(H_data)
        [r_min, r_max] = Omega
        y = ((r_max - r_min)/(s_max-s_min))*(H_data-s_min) + r_min
        FH_data = filter_function(y)
        F_mat = coo_matrix((FH_data, (np.arange(M), np.arange(M))), shape=(M, M))
        self.filtered_H = F_mat

class GNQA_main(GNQA_functions):
    
    def __init__(self, qubo):
        super().__init__(qubo)
    
    def initialize_param(self, theta):
        self.theta = theta

    def update_param(self, perturbation=False):
        eta = 1 / super().calculation_expectation(self.theta)
        dW = np.zeros(self.N)
        for idx in range(self.N):
            W_1 = self.theta.copy()
            W_1[idx] += pi/4
            val_1 = super().calculation_expectation(W_1)

            W_2 = self.theta.copy()
            W_2[idx] -= pi/4
            val_2 = super().calculation_expectation(W_2)

            dW[idx] = (val_1 - val_2) /2
        self.theta += eta*dW

        if perturbation:
            self.theta += np.random.normal(loc=0, scale=1e-3, size=self.N)

class GNQA_optimizer(GNQA_main):
    
    def __init__(self, qubo):
        super().__init__(qubo)
    
    def solve(self, step_max=10):
        super().eval_objective_function()
        record = np.array([self.obj_val])
        for step in range(step_max):
            super().update_param()
            super().indicator()
            record = np.append(record, self.fval)
        
        self.result_as_df = pd.DataFrame(record,
                    columns=['objective function value'],
                    index=[f'step {j}' for j in range(len(record))]
                    )
        
        status = self.qubo.get_feasibility_info(self.x)
        if status:
            s_val = 0
        else:
            s_val = 2

        return OptimizationResult(
                x = self.x,
                fval = self.fval,
                variables = self.qubo.variables,
                raw_results = None,
                status = OptimizationResultStatus(s_val)
            )
