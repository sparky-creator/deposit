## Installation guide

Follow the steps below to establish your development environment so that you are prepared to run the code in the notebooks.


### Download and extract the sources
Download and extract the tutorial and sources.


### Set up a virtual Python environment
We assume that [Python](https://wiki.python.org/moin/BeginnersGuide/Download) is already installed onto your local system. We recommend using [Python virtual environments](https://docs.python.org/3/library/venv.html) to isolate the IBM Quantum Asset Library notebooks from other applications and make it easier to access the packages you need. There are two options to set up a virtual environment: through either a venv or a conda environment.

#### Option 1: venv (included in Python)
1. Create a virtual environment with only Python installed in it.

    ```python3 -m venv asset-lib-env```

2. Then, activate your new virtual environment.

    ```source asset-lib-env/bin/activate```


#### Option 2: conda (recommended only if it is your tool of choice)

1. Create a conda environment.

    ```conda create --name asset-lib-env python=3.10```

2. Activate the conda environment.

    ```conda activate asset-lib-env```


### Install dependencies

Install the IBM Quantum Asset Library packages.

    pip install -r requirements.txt

You can run `pip list` to view the active packages in your virtual environment and ensure the packages were installed successfully.

From here you can open your Jupyter notebook and start working!




