# Copyright (C) 2021-2023 IBM Quantum
#
# This code is categorized as "existing" IBM asset
# as a part of Quantum Acceleration contract.

# @author: Shungo Miyabe and Noriaki Shimada


import numpy as np
from sklearn.preprocessing import scale
from sklearn.utils import check_array
from lingam import DirectLiNGAM

class qDirectLiNGAM(DirectLiNGAM):
    """Implementation of quantum LiNGAM Algorithm [1]

    Reference
    ----------
    .. [1] H. Kawaguchi, arxiv:2110.04485 (2021).
    .. [2] The LiNGAM Project: https://sites.google.com/site/sshimizu06/lingam
    """

    def __init__(
        self,
        random_state=None,
        prior_knowledge=None,
        apply_prior_knowledge_softly=False,
        measure="pwling",
    ):
        """
        Parameters:
        ----------
        random_state : int, optional (default=None)
            Seed for the random number generator
        prior_knowledge : array-like, shape (n, m), optional (default=None)
            Prior knowledge used for causal discovery, where n and m are the number of features and the number of samples, respectively.

            The elements of prior knowledge matrix [2]_:

            * ``0`` : :math:`x_i` does not have a directed path to :math:`x_j`
            * ``1`` : :math:`x_i` has a directed path to :math:`x_j`
            * ``-1`` : No prior knowledge is available to know if either of the two cases above (0 or 1) is true.
        apply_prior_knowledge_softly : boolean, optional (default=False)
            If True, apply prior knowledge softly.
        measure : {'pwling', 'kernel'}, optional (default='pwling')
            Measure used to evaluate independence: 'pwling' or 'kernel' [2]_.
        """
        super().__init__(random_state)
        self._Aknw = prior_knowledge
        self._apply_prior_knowledge_softly = apply_prior_knowledge_softly
        self._measure = measure

        if self._Aknw is not None:
            self._Aknw = check_array(self._Aknw)
            self._Aknw = np.where(self._Aknw < 0, np.nan, self._Aknw)

    def fit(self, X, kernel=None, NOCCO=False, epsilon=1e-5, actfunc=None):
        """Fit the model to X.

        Parameters:
        ----------
        X : array-like, shape (n, m)
            Training data
            n: number of samples
            m: number of features

        Returns
        -------
        self : object
            Returns the instance itself.
        """
        # Check parameters
        X = check_array(X)
        n_features = X.shape[1]

        # Check prior knowledge
        if self._Aknw is not None:
            if (n_features, n_features) != self._Aknw.shape:
                raise ValueError(
                    "The shape of prior knowledge must be (n_features, n_features)"
                )
            else:
                # Extract all partial orders in prior knowledge matrix
                if not self._apply_prior_knowledge_softly:
                    self._partial_orders = self._extract_partial_orders(self._Aknw)

        # Causal discovery
        U = np.arange(n_features)
        K = []
        X_ = np.copy(X)
        if self._measure == "kernel":
            X_ = scale(X_)

        for _ in range(n_features):
            if self._measure == "kernel":
                m = self._search_causal_order_kernel_q(X_, U, kernel=kernel, NOCCO=NOCCO, epsilon=epsilon, actfunc=actfunc)
            else:
                m = self._search_causal_order(X_, U)
            for i in U:
                if i != m:
                    X_[:, i] = self._residual(X_[:, i], X_[:, m])
            K.append(m)
            U = U[U != m]
            # Update partial orders
            if (self._Aknw is not None) and (not self._apply_prior_knowledge_softly):
                self._partial_orders = self._partial_orders[
                    self._partial_orders[:, 0] != m
                ]

        self._causal_order = K
        return self._estimate_adjacency_matrix(X, prior_knowledge=self._Aknw)

    def _mutual_information_q(self, x1, x2, param, kernel=None, NOCCO=False, epsilon=1e-5, actfunc=None):
        """Calculate the mutual informations."""
        kappa, sigma = param
        n = len(x1)
        if not kernel:
            X1 = np.tile(x1, (n, 1))
            K1 = np.exp(-1 / (2 * sigma ** 2) * (X1 ** 2 + X1.T ** 2 - 2 * X1 * X1.T))
            X2 = np.tile(x2, (n, 1))
            K2 = np.exp(-1 / (2 * sigma ** 2) * (X2 ** 2 + X2.T ** 2 - 2 * X2 * X2.T))
        else:
            if actfunc is not None:
                x1 = actfunc(x1)
                x2 = actfunc(x2)
            x1 = x1.reshape(n, 1)
            x2 = x2.reshape(n, 1)
            K1 = kernel.evaluate(x1, x1)
            K2 = kernel.evaluate(x2, x2)

        MI = 0
        if NOCCO:
            In = n * epsilon * np.identity(n)
            RY = np.dot(K1, np.linalg.inv(K1 + In))
            RX = np.dot(K2, np.linalg.inv(K2 + In))
            MI = np.trace(np.dot(RY, RX))
        else:
            tmp1 = K1 + n * kappa * np.identity(n) / 2
            tmp2 = K2 + n * kappa * np.identity(n) / 2
            K_kappa = np.r_[np.c_[tmp1 @ tmp1, K1 @ K2], np.c_[K2 @ K1, tmp2 @ tmp2]]
            D_kappa = np.r_[
                np.c_[tmp1 @ tmp1, np.zeros([n, n])], np.c_[np.zeros([n, n]), tmp2 @ tmp2]
            ]

            #sigma_K = np.linalg.svd(K_kappa, compute_uv=False)
            #sigma_D = np.linalg.svd(D_kappa, compute_uv=False)
            sigma_K = np.linalg.det(K_kappa)
            sigma_D = np.linalg.det(D_kappa)
            MI = (-1 / 2) * (np.sum(np.log(sigma_K)) - np.sum(np.log(sigma_D)))
        return MI

    def _search_causal_order_kernel_q(self, X, U, kernel=None, NOCCO=False, epsilon=1e-5, actfunc=None):
        """Search the causal ordering by kernel method."""
        Uc, Vj = self._search_candidate(U)
        if len(Uc) == 1:
            return Uc[0]

        if X.shape[0] > 1000:
            param = [2e-3, 0.5]
        else:
            param = [2e-2, 1.0]

        Tkernels = []
        for j in Uc:
            Tkernel = 0
            for i in U:
                if i != j:
                    ri_j = (
                        X[:, i]
                        if j in Vj and i in Uc
                        else self._residual(X[:, i], X[:, j])
                    )
                    Tkernel += self._mutual_information_q(X[:, j], ri_j, param, kernel=kernel, NOCCO=NOCCO, epsilon=epsilon, actfunc=actfunc)
            Tkernels.append(Tkernel)

        return Uc[np.argmin(Tkernels)]

    def _qkernel_evaluate(self, x, kernel):
        n = len(x)
        K = np.zeros((n,n))
        for i in range(n):
            for j in range(i,n):
                if i == j:
                    K[i,j] = 1.
                else:
                    K[i,j] = kernel.evaluate(np.array([x[i]]).reshape(1,1),np.array([x[j]]).reshape(1,1))
                    K[j,i] = K[i,j]
        return K

