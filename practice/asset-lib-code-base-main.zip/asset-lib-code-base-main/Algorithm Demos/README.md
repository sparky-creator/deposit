## Technical prototypes 
The technical prototype notebook explains the algorithm through a use case. 


## Requirements for notebook
1. Algorithm should have a folder with name of the algorithm.
2. Name of algorithm notebook should be `Tutorial.ipynb`.
3. Notebook should have an introduction with summary points of what is explained in the tutorial.
4. At the end of the notebook there should be a summary recapping what has been explained.
5. Bottom of notebook should have references.
6. Notebook should include copy right statement. 


## Abstract (for editors and reviewers)
This outline should also help you organize your content. Please provide information about the following elements for the reviewing process. Choose the focus area relevant to your topic. <br>
**Machine learning**
- Use case -> data set (explain objective/goal with the data set)
- Task classification, regression, forecasting etc.
- Key concept/novelty quantum enhancement 
- Problem with the classical model
- Benefit

**Optimization**
- Use case/problem
- Mathematical problem (QUBO, max-cut, combinatorial problem)
- Key concept/novelty quantum enhancement 
- Problem the classical model
- Benefit

**Chemistry**
- Use case/problem
- Material Hamiltonian (molecule, lattice, etc)
- Key concept/novelty quantum enhancement 
- Problem with the classical model
- Benefit


 
For questions please reach out to Laura Schleeper.
