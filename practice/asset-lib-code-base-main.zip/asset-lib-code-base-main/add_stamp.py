import os
import nbformat as nbf
from nbformat.v4 import new_markdown_cell

def add_cell_to_all_notebooks(folder_path, content):
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith('.ipynb'):
                file_path = os.path.join(root, file)
                add_cell_to_notebook(file_path, content)

def add_cell_to_notebook(file_path, content):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            notebook = nbf.read(f, as_version=4)

        new_cell = new_markdown_cell(content)
        notebook.cells.append(new_cell)

        with open(file_path, 'w', encoding='utf-8') as f:
            nbf.write(notebook, f)
    except Exception as e:
        print("Exception in "+str(file_path))
        print(e)


if __name__ == '__main__':
    #folder_path = 'Algorithm Demos'
    #folder_path = 'Algorithms'
    folder_path = 'Essentials/Optimization'
    content = """<span style="font-size:10pt; font-weight:bold;"> &copy; Copyright IBM Corp. 2023 <br/>This code is categorized as an “existing” IBM asset as part of the IBM Quantum Accelerator contract. </span>"""

    add_cell_to_all_notebooks(folder_path, content)
