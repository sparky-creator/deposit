import json
import re
import sys

def replace_backend_in_notebook(filename):
    # Define a regex pattern to match service.backend("...")
    # where "..." is not "ibmq_qasm_simulator"
    pattern = r'service\.backend\("(?!ibmq_qasm_simulator")[^"]*"\)'

    # Replacement string
    replacement = 'service.backend("ibmq_qasm_simulator")'

    # Read the notebook
    with open(filename, 'r') as f:
        notebook = json.load(f)

    # Check each cell and replace the content as necessary
    for cell in notebook['cells']:
        if cell['cell_type'] == 'code':
            cell['source'] = [
                re.sub(pattern, replacement, line)
                for line in cell['source']
            ]

    # Save the modified notebook
    with open(filename, 'w') as f:
        json.dump(notebook, f, indent=4)

def main():
    if len(sys.argv) < 2:
        print("Usage: python script_name.py notebook_filename.ipynb")
        return

    notebook_filename = sys.argv[1]
    replace_backend_in_notebook(notebook_filename)
    print(f"Processed: {notebook_filename}")

if __name__ == "__main__":
    main()