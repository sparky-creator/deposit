import nbformat


def normalize_notebook(notebook_path):
    """
    Normalize a Jupyter notebook to add missing cell IDs.

    Args:
    - notebook_path (str): Path to the notebook file.
    """
    # Load the notebook
    with open(notebook_path, 'r', encoding='utf-8') as f:
        notebook = nbformat.read(f, as_version=4)

    # Normalize the notebook
    notebook = nbformat.normalize(notebook)

    # Save the normalized notebook
    with open(notebook_path, 'w', encoding='utf-8') as f:
        nbformat.write(notebook, f)


def main(args):
    if len(args) == 1:
        normalize_notebook(args[1])