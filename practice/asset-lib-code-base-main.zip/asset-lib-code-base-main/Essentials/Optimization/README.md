# Optimization 
A course that provides in-depth knowledge about quantum algorithms used for optimization.

**Get Started**
* Learning expectations
* Introduction

**Classical optimizers**	
* Overview
* Analytical calculations and the basic gradient descent algorithm
* Sequential quadratic programming (SQP) algorithm
* Broyden Fletcher Goldfarb Shanno (BFGS) algorithm
* Nelder-Mead algorithm
* Constrained optimization by linear approximation (COBYLA)
* Simultaneous perturbation stochastic approximation (SPSA)

**Quantum approach to optimization**	
* Overview
* Why quantum for optimization
* Hamiltonian mapping
* Hamiltonian for two level systems
* Hamiltonian for optimization problems
* Converting QUBO to operator
* Exact set cover example

**Variational quantum optimization algorithms**
* Overview
* Importance of variational algorithms in optimization
* Introduction to QAOA
* Components of QAOA
* Steps with diamond graph
* Approximate optimization algorithms full deduction with a butterfly graph
* QAOA on simulator and real device

**Universal quantum optimization algorithms**
* Grover adaptive search (GAS) overview
* Grover adaptive search (GAS)
* Grover adaptive search use case
* Quantum random walk overview
* Quantum random walk 
	* Part one
	* Part two
	    
**Industry problem example**
* Overview
* Solving the capacitated vehicle routing problem with time windows

**Reflection**	
* Course feedback