# Random walk
A random walk is a random process that describes a path of successive random steps on some mathematical space. The concept of random walk began in classical computations and was later redefined in quantum computations.

We discuss a classical random walk, then focus on the quantum random walk, which is part of universal quantum optimization algorithm family.

### Learning objectives
* Understand classical random walk
* Understand quantum walk
* Discuss quantum walk based algorithms
