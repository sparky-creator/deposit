# Quantum machine learning
### Data Mining Steps: 

## 1. Business understanding
  - Determine business objectives
  - Assess situation
  - Determine data mining goals
  - Produce project plan
## 2. Data understanding 
  - Collect initial data
  - Describe data
  - Explore data
  - Verify data quality
## 3. Data preparation
  - Select data
  - Clean data
  - Construct data
  - Integrate data
  - Format data
## 4. Modeling
  - Select modeling technique
  - Generate test design
  - Build model
  - Assess model
## 5. Evaluation
  - Evaluate results
  - Review process
  - Determine next steps
## 6. Deployment 
  - Plan deployment
  - Plan monitoring and maintenance 
  - Produce final report
  - Review project
