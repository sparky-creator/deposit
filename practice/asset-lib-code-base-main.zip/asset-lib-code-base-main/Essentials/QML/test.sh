python3.10 -m venv test-env
source test-env/bin/activate
pip install -U pip
pip install -U setuptools
pip install wheel
pip install pytest-xdist
pip install -r ../../_tools/test_requirements.txt


python -m ipykernel install --user --name=test-kernel
pip install -r requirements.txt



pytest --nbmake --nbmake-timeout=3000 --nbmake-kernel=test-kernel -n=auto --overwrite \
  'QML course content'/*/*.ipynb \
  'QML course content'/*/*/*.ipynb \
  'QML pipeline content'/*/*.ipynb

# pytest --nbmake --nbmake-timeout=3000 -n=auto QML*/*/*.ipynb

status=$?
# pip install pipdeptree
# pipdeptree
deactivate
rm -R test-env
if [ $status -eq 0 ]
then
  echo "Success: Test execution succeeded."
  exit 0
else
  echo "Failure: Some tests have failed!" >&2
  exit 1
fi