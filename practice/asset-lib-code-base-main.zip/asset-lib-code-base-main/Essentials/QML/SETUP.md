## Installation steps for conda:

conda create -n My_Env_Name python=3.10

conda activate My_Env_Name

pip install -r requirements.txt
