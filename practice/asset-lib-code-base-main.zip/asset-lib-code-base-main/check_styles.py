# Copyright (C) 2021-2023 IBM Quantum
#
# This code is categorized as "existing" IBM asset
# as a part of Quantum Acceleration contract.

import os
import nbformat as nbf


def check_all_files(folder_path, content, ignored, file_type):
    all_found = True
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith(file_type):
                file_path = os.path.join(root, file)
                if not file_ignored(file_path, ignored):
                    if file_type == '.ipynb':
                        if not check_cell_in_notebook(file_path, content):
                            all_found = False
                    else:
                        if not check_file(file_path, content):
                            all_found = False
    return all_found


def check_all_notebooks(folder_path, content, ignored):
    return check_all_files(folder_path, content, ignored, '.ipynb')


def file_ignored(file_path, ignored):
    for ignored_prefix in ignored:
        if file_path.startswith(ignored_prefix):
            return True
    return False


def check_cell_in_notebook(file_path, content):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            notebook = nbf.read(f, as_version=4)

        content_found = False
        cell = notebook.cells[0]
        if cell.cell_type == 'code' and content in cell.source:
            content_found = True

        if not content_found:
            raise ValueError(f"Content '{content}' not found in {file_path}")

    except Exception as e:
        print("Exception in "+str(file_path))
        print(e)
        return False
    return True



def check_file(file_path, content):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            file_contents = f.read()

            if content not in file_contents:
                raise ValueError(f"Content '{content}' not found in {file_path}")

    except Exception as e:
        print("Exception in " + str(file_path))
        print(e)
        return False
    return True


if __name__ == '__main__':
    #folder_path = 'Algorithm Demos'
    #folder_path = 'Algorithms'
    ignored = {
    }

    content = "import ibmJupyterNotebookStyles\nibmJupyterNotebookStyles.apply_ibm_styles()"
    all_found = True

    folder_path = 'Algorithm Demos'
    if not check_all_notebooks(folder_path, content, ignored):
        all_found = False

    folder_path = 'Algorithms'
    if not check_all_notebooks(folder_path, content, ignored):
        all_found = False


    folder_path = 'Essentials'
    if not check_all_notebooks(folder_path, content, ignored):
        all_found = False

    print(all_found)

    exit(0 if all_found else 1)
