# Advanced algorithms
The algorithm notebook explains the algorithm through a toy example and has typically detailed explanation of the mathematics of the algorithm.

## Requirements for notebook
1. Algorithm should have a folder with name of the algorithm.
2. Name of algorithm notebook should be `Tutorial.ipynb`.
3. Notebook should have an introduction with summary points of what is explained in the tutorial.
4. At the end of the notebook there should be a summary recapping what has been explained.
5. Bottom of notebook should have references.
6. Notebook should include copy right statement. 
