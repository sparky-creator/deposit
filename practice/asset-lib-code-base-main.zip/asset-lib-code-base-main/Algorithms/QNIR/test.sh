python3.10 -m venv test-env
source test-env/bin/activate
pip install -U pip
pip install -U setuptools
pip install wheel
pip install nbmake
python -m ipykernel install --user --name=test-kernel

pip install -r requirements.txt

pytest --nbmake --nbmake-timeout=3000 --nbmake-kernel=test-kernel --overwrite *.ipynb
status=$?

python ../../_tools/check_warnings.py .
warnings_status=$?
echo $warnings_status
# pip install pipdeptree
# pipdeptree
deactivate
rm -R test-env
if [ $status -eq 0 ]
then
  echo "Success: Test execution succeeded."
  exit $warnings_status
else
  echo "Failure: Some tests have failed!" >&2
  exit 1
fi