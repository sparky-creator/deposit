# Copyright (C) 2021-2023 IBM Quantum
#
# This code is categorized as "existing" IBM asset
# as a part of Quantum Acceleration contract.

# @author: Daniel Fry

import numpy as np
from sklearn.metrics import mean_absolute_error


def mape_metric(y_true, y_pred):
    # check arrays have the same length
    assert y_true.shape[0] == y_pred.shape[0]
    # reshape arrays to make sure they're the same shape
    y_true = y_true.reshape((-1, 1))
    y_pred = y_pred.reshape((-1, 1))
    # return MAPE calculation
    return (np.sum(np.abs((y_true - y_pred)/y_true))) / y_true.shape[0]


def mase_metric(onestep_ahead_model,
                twostep_ahead_model,
                y_true):
    '''
    MASE is a forecasting metric with good properties like being scale
    independent, symmetric and interpretable.

    MASE = MAE(error) / MAE(Naive forecast)
    https://en.wikipedia.org/wiki/Mean_absolute_scaled_error

    MASE is the MAE of a given model predictions divided by and the MAE of
    the Naive model predictions.

    Note: This means that the arrays have to be shortened because the first
    value in the y_true array can't be predicted by the Naive model from the
    given input arrays.

    A MASE value less than 1 means the given model performs better than the
    Naive forecast model.
    A MASE value equal to 1 means the given model performs equal to the Naive
    forecast model.
    A MASE value of greater than 1 means the given model performs worse than
    the Naive forecast model.

    The input arrays need to be shortened to make them the same length as the
    naive model forecast arrays which require one and two lead values from the
    input array.
    '''
    # Make sure the lengths of input arrays are what is expected
    assert len(onestep_ahead_model) == len(twostep_ahead_model) + 1
    assert len(onestep_ahead_model) == len(y_true)

    def naive_forecast_2step(y_true):
        '''
        Naive forecast propagates values 2 steps ahead.
        -
        Returns a RxC = (n-1)x2 array, containing (n-1) rows and 2 cols for
        the 2 timesteps ahead.
        '''
        y_true = y_true.reshape((-1, 1))        # Uses correct shape
        y_temp = np.hstack((y_true, y_true))    # Duplicates col
        y_pred = y_temp[:-1, :]                 # Removes last row
        return y_pred

    # Extract arrays from naive_forecast_2step output
    onetwo_naive_forecast = naive_forecast_2step(y_true)
    onestep_ahead_naive = onetwo_naive_forecast[:, 0]
    twostep_ahead_naive = onetwo_naive_forecast[:-1, 1]

    # Ensure array shapes are the same for further calculations
    onestep_ahead_naive = onestep_ahead_naive.reshape(-1,)
    twostep_ahead_naive = twostep_ahead_naive.reshape(-1,)
    onestep_ahead_model = onestep_ahead_model.reshape(-1,)
    twostep_ahead_model = twostep_ahead_model.reshape(-1,)
    y_true = y_true.reshape(-1,)

    # shorten input arrays from the front - see MASE docstring
    onestep_ahead_model = onestep_ahead_model[1:]
    twostep_ahead_model = twostep_ahead_model[1:]
    y_true = y_true[1:]

    # one and two step ahead y_true
    y_true_long = np.concatenate((y_true, y_true[1:]))

    # one and two step ahead naive forecast
    # MAE for naive forecasts
    onetwo_ahead_naive = np.concatenate((onestep_ahead_naive,
                                         twostep_ahead_naive))
    mae_naive = mean_absolute_error(y_true_long, onetwo_ahead_naive)

    # one and two step ahead model forecasts
    # MAE for model forecasts
    onetwo_ahead_model = np.concatenate((onestep_ahead_model,
                                         twostep_ahead_model))
    mae_model = mean_absolute_error(y_true_long, onetwo_ahead_model)

    # MASE
    mase = mae_model/mae_naive
    return mase


def mase_metric_1ahead(y_true, onestep_ahead_model):
    # Make sure the lengths of input arrays are what is expected
    assert len(onestep_ahead_model) == len(y_true)

    def naive_forecast_1step(y_true):
        y_true = y_true.reshape((-1, 1))     # Uses correct shape
        y_pred = y_true[:-1]                 # Removes last element
        return y_pred

    # Extract arrays from naive_forecast_1step output
    onestep_ahead_naive = naive_forecast_1step(y_true)

    # Ensure array shapes are the same for further calculations
    onestep_ahead_naive = onestep_ahead_naive.reshape(-1,)
    onestep_ahead_model = onestep_ahead_model.reshape(-1,)
    y_true = y_true.reshape(-1,)

    # shorten input arrays from the front - see MASE docstring
    onestep_ahead_model = onestep_ahead_model[1:]
    y_true = y_true[1:]

    mae_naive = mean_absolute_error(y_true, onestep_ahead_naive)
    mae_model = mean_absolute_error(y_true, onestep_ahead_model)

    # MASE
    mase = mae_model/mae_naive
    return mase
