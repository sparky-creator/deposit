# Copyright (C) 2021-2023 IBM Quantum
#
# This code is categorized as "existing" IBM asset
# as a part of Quantum Acceleration contract.

# @author: Daniel Fry

import numpy as np
from qiskit.quantum_info import Kraus
from qiskit_aer.noise import reset_error
from qiskit_aer import QasmSimulator
from qiskit import QuantumCircuit, QuantumRegister


class APBestProbs:
    '''Best probability parameter list for Air Passenger tutorial'''
    def __init__(self):
        self.best_probs = [0.5466628950089216,
                           0.04005198925733566,
                           0.8639272451400757,
                           0.4303177371621132,
                           0.8435903340578079,
                           0.4028535559773445,
                           0.04445039480924606,
                           0.6244770735502243,
                           0.12515581026673317,
                           0.6422457695007324,
                           0.658624678850174,
                           0.02850165218114853,
                           0.7726031057536602,
                           0.3696688190102577]
    
    def best_probs(self):
        return self.best_probs


def resetnoise_kraus_list(num_qubits, prob_list):
    '''
    '''
    rx_params = prob_list[:num_qubits]
    cx1_params = prob_list[num_qubits:2*num_qubits]
    cx2_params = prob_list[2*num_qubits:3*num_qubits]
    cx_params = np.append(cx1_params, cx2_params)
    rz_params = prob_list[3*num_qubits:]

    def kraus_channel(parameter):
        '''Reset0 noise Kraus operators'''
        return Kraus(reset_error(parameter))

    # Noise errors
    rz_errors = [kraus_channel(a) for a in rz_params]
    rx_errors = [kraus_channel(a) for a in rx_params]
    cx_errors = [kraus_channel(a) for a in cx_params]

    return [rz_errors, rx_errors, cx_errors]


class Z_exp_vals:
    """Class for computing measurement ops and expectation values"""
    def __init__(self, num_qubits):
        self.measure_ops = self._compute_zoperators(num_qubits)
    
    def _compute_zoperators(self, num_qubits):
        ops_list = []
        z = np.array([1,-1])

        ops_list.append(np.kron(np.ones(2**(num_qubits-1)), z))

        for j in range(1, num_qubits-1):
            first_is = np.ones(2**(num_qubits-1-j))
            last_is = np.ones(2**(j))
            ops_list.append(np.kron(np.kron(first_is, z), last_is))

        ops_list.append(np.kron(z, np.ones(2**(num_qubits-1))))
        return ops_list

    def expectation_values(self, dm):
        exp_list = []
        for op in self.measure_ops:
            exp_list.append(np.dot(op, np.diag(dm).real))
        return exp_list


def qr_circ_with_noise(qc, angle, kraus_list):
    for j, i in zip(range(0, qc.num_qubits, 2), range(int(qc.num_qubits/2))):
        qc.rx(angle, j)
        qc.append(kraus_list[1][j], [j])
        qc.rx(angle, j+1)
        qc.append(kraus_list[1][j+1], [j+1])
        
        qc.cx(j, j+1)
        qc.append(kraus_list[2][j], [j])
        qc.append(kraus_list[2][j+1], [j+1])
        
        qc.rz(angle, j+1)
        qc.append(kraus_list[0][i], [j+1])
        
        qc.cx(j, j+1)
        qc.append(kraus_list[2][j], [j])
        qc.append(kraus_list[2][j+1], [j+1])
    return qc 


def qr_entang_circ_noise(qc, angle, kraus_list):
    '''Implements linear entanglement. (Not circle entanglement)'''
    qc.rx(angle, 0)
    qc.append(kraus_list[1][0], [0])
    for j in range(1, qc.num_qubits):
        qc.rx(angle, j)
        qc.append(kraus_list[1][j], [j])
        
        qc.cx(j-1, j)
        qc.append(kraus_list[2][j-1], [j-1])
        qc.append(kraus_list[2][j], [j])
        
        qc.rz(angle, j)
        qc.append(kraus_list[0][j], [j])
        
        qc.cx(j-1, j)
        qc.append(kraus_list[2][j-1], [j-1])
        qc.append(kraus_list[2][j], [j])
    qc.barrier()
    return qc

    
def qnir_algorithm(input_array, target_array, prob_list):
    '''main'''
    assert len(prob_list) == int(3.5*12)  # check num of params
    
    N = len(input_array)
    s = input_array
    y = target_array
    
    iterations = 3
    subqn = 4  # reservoir qubits per iteration *keep value*
    #total_num_qbs = iterations*subqn
    sub_len = int(len(prob_list)/iterations)

    # calculate expectation values in numpy
    zops = Z_exp_vals(subqn)
    all_exp_value_list = []

    for i in range(iterations):
        q = QuantumRegister(subqn, 'q')
        circ = QuantumCircuit(q)
        
        sub_prob_list = prob_list[i*sub_len:(i+1)*sub_len]
        # extract new part of kraus_list in each iteration
        kraus_list = resetnoise_kraus_list(subqn, sub_prob_list)
        # initial state prep
        circ.h(q)

        for i in range(N):
            circ = qr_circ_with_noise(circ, s[i], kraus_list)
            dmlabel = f'dm{i}'
            circ.save_density_matrix(label=dmlabel)

        # single precision same as double precision to 5/6 decimal places.
        backend = QasmSimulator(method='density_matrix', precision='single')
        result = backend.run(circ)

        # get saved data and compute Z_exp_vals.expectation_values
        exp_values_list = []
        for r in range(N):
            results_label = f'dm{r}'
            results_dm = result.result().data(0)[results_label]
            exp_values_list.append(zops.expectation_values(results_dm))

        all_exp_value_list.append(exp_values_list)

    # collect output arrays into one array
    wo_ = np.array(all_exp_value_list[0])
    for l in range(1, len(all_exp_value_list)):
        wo_ = np.hstack((wo_, np.array(all_exp_value_list[l])))
        
    return wo_


def qnir_algorithm_qb(input_array, target_array, prob_list, num_qubits):
    '''variable number of qubits'''
    assert num_qubits % 4 == 0  # only multiples of 4
    assert len(prob_list) == int(3.5*num_qubits)  # check num of params
    
    N = len(input_array)
    s = input_array
    y = target_array
    
    iterations = int(num_qubits/4)
    subqn = 4  # reservoir qubits per iteration *keep value*
    #total_num_qbs = iterations*subqn
    sub_len = int(len(prob_list)/iterations)

    # calculate expectation values in numpy
    zops = Z_exp_vals(subqn)
    all_exp_value_list = []

    for i in range(iterations):
        q = QuantumRegister(subqn, 'q')
        circ = QuantumCircuit(q)
        
        sub_prob_list = prob_list[i*sub_len:(i+1)*sub_len]
        # extract new part of kraus_list in each iteration
        kraus_list = resetnoise_kraus_list(subqn, sub_prob_list)
        # initial state prep
        circ.h(q)

        for i in range(N):
            circ = qr_circ_with_noise(circ, s[i], kraus_list)
            dmlabel = f'dm{i}'
            circ.save_density_matrix(label=dmlabel)

        # single precision same as double precision to 5/6 decimal places.
        backend = QasmSimulator(method='density_matrix', precision='single')
        result = backend.run(circ)

        # get saved data and compute Z_exp_vals.expectation_values
        exp_values_list = []
        for r in range(N):
            results_label = f'dm{r}'
            results_dm = result.result().data(0)[results_label]
            exp_values_list.append(zops.expectation_values(results_dm))

        all_exp_value_list.append(exp_values_list)

    # collect output arrays into one array
    wo_ = np.array(all_exp_value_list[0])
    for l in range(1, len(all_exp_value_list)):
        wo_ = np.hstack((wo_, np.array(all_exp_value_list[l])))
        
    return wo_
