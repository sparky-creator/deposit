execute_test() {
    echo "Testing $1"
    while sleep 9m; do echo "=====[ $(expr $SECONDS / 60).$(expr $SECONDS % 60) minutes and still running ]====="; done &
    cd "$1" && ./test.sh
    local exit_code=$?
    kill %1
    return $exit_code
}

test_asset() {
    echo Calling test_asset for: $1
    echo $TRAVIS_EVENT_TYPE
    echo "****"
    status=0
    if [ $TRAVIS_EVENT_TYPE = "cron" ] ; then
          execute_test "$1"
          local exit_code=$?
          return $exit_code
    else 
        while read file; do
        echo "$file"
        if [[ "$file" == "$1"* ]]; then
            execute_test "$1"
            local exit_code=$?
            return $exit_code
        fi
        done <<< $CHANGED_FILES
    fi

}