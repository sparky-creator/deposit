

# Welcome to the Assets library code base!

[![Build Status](https://v3.travis.ibm.com/gbs-ibm-q/asset-lib-code-base.svg?token=2azTxexRp9uxFux2uPCy&branch=main)](https://v3.travis.ibm.com/gbs-ibm-q/asset-lib-code-base)


In this repo we collect all the assets for the asset library. The following 6 asset can be found on the asset library:
1. **Technical prototype** (algorithmic demo): algorithm demonstrated through use case. Contains overview (business value), tutorial(code + explanation) 
2. **Advanced algorithm** (algorithm): algorithm explained through toy example. Contains tutorial (code + explanation)
3. **Essentials**: content which is essential for guide prototyping. Contains among other things: old advance course modules, error mitigation techniques, runtime tutorial.  
4. **Insights**: blog posted. Contains blog posts on new papers released by team, IBM Quantum updates, and more. 
5. **Reference architecture**: tbd
6. **Digital prototype**: tbd

## Important deadlines:
- **July 7**: batch 1 finished. Batch 1 includes 10 technical prototypes + 8 advanced algorithms peer review feedback integrated.

## Creating new asset
Each new asset is created in a new branch. Please check the README file within the folder of your asset type what the requirements and steps are. 

## Steps
1. Create a new branch + folder with the working name of your asset.
2. Copy all files from template folder of your asset type into your newly created folder.
    - Technical prototype: [template folder](https://github.ibm.com/gbs-ibm-q/asset-lib-code-base/tree/2bc110ce884351a9de482505a2be8c250fcc6053/Algorithm%20Demos/TemplateAsset).
    - Advanced algorithm: [template folder](https://github.ibm.com/gbs-ibm-q/asset-lib-code-base/tree/main/Algorithms/TemplateAsset).
3. Use [Tutorial.ipynb](https://github.ibm.com/gbs-ibm-q/asset-lib-code-base/blob/5e213e2368337bd71bf80bb2877379d9bdf238fa/Algorithm%20Demos/TemplateAsset/Tutorial.ipynb) within the template folder to start your tutorial notebook. 
4. When you finish the Tutorial.ipynb assign Laura as reviewer in your Pull Request (PR). 
5. When all the requirements are met Laura will merge the folder into the main branch.
6. Technical prototype push to dev website.
7. Review by writers for grammer and spelling.
8. Peer review workstream member from content on website.
9. Content is push to production website. 

## Development flow
<img src="Development_flow.png" alt="Development flow" style="width:800px;">


## Links:
- Website Asset library: https://assets.quantum-computing.ibm.com/
- Staging: https://asset-library.102hht8t5kit.us-south.codeengine.appdomain.cloud/
