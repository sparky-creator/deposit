# News

## Table of contents

- Introduction
- Requirements
- Installation
- Configuration

## Introduction

The News asset category includes blog-type articles that share recent happenings, research, and updates relevant to the IBM Quantum Asset Library. The framework for each News asset is comprised of an article title, short description, tags, and two tabs: an Article tab and a Related Assets tab. The Article tab contains the text of the article, including any media elements such as embedded videos and hyperlinked articles/PDFs. The Related Assets tab contains cards for assets that have been tagged as relevant to the article content—recommended reading, essentially. Each article should be dated according to its publication date in the format DD MM YYYY.

Learn more about the schedule of the News posts by viewing the [editorial calendar](https://airtable.com/invite/l?inviteId=invoL98U0igMeSXV9&inviteToken=4cc849fcd8738ee3757b87a224fb49c1e19dbb519ca3500e5341e241d6c0f382&utm_medium=email&utm_source=product_team&utm_content=transactional-alerts) in Airtable.

Submit bug reports and feature suggestions to the [issue queue](https://jsw.ibm.com/projects/QUAN/issues/) or contact [Jennifer Janechek](Jennifer.Janechek@ibm.com).

## Requirements

No special requirements.

## Installation

Install like the other assets.

## Configuration

All Asset Library users should have view permissions to the News category.
