import numpy as np

from qiskit import Aer, ClassicalRegister, execute, QuantumRegister, transpile
from qiskit.circuit import QuantumCircuit
from qiskit.extensions import RYGate, XGate
from qiskit.quantum_info import Operator, Statevector

from banded_circulant_matrix import indices, find_angles


def block_encoding(alpha, beta, gamma, num_sys_qubits, i=0, j=0, add_measurements=False):
    # log(s)
    num_aux_qubits = 2

    # initialise quantum registers
    qa = QuantumRegister(size=1, name="a")
    ql = QuantumRegister(size=num_aux_qubits, name="l")

    # qubits representing |b> and solution |x>
    qx = QuantumRegister(size=num_sys_qubits, name="x")

    # initialise the quantum circuit
    if add_measurements:
        ca = ClassicalRegister(size=1, name="ca")
        cl = ClassicalRegister(size=num_aux_qubits, name="cl")
        qc = QuantumCircuit(qa, ql, qx, ca, cl, name="$U_A$")
    else:
        qc = QuantumCircuit(qa, ql, qx, name="$U_A$")

    t1, t2, t3 = find_angles(alpha, beta, gamma)

    # state preparation
    for k in indices(i):
        qc.x(qx[k])

    # diffusion operator
    qc.h(ql)

    # O_A
    ry = RYGate(t1)
    qc.append(ry.control(2, ctrl_state="00"), ql[:] + [qa[0]])
    qc.cry(t2, ql[0], qa, ctrl_state="1")
    qc.cry(t3, ql[1], qa, ctrl_state="1")

    # eliminate two elements
    ry = RYGate(- np.pi - t3)
    qc.append(ry.control(num_sys_qubits + 2, ctrl_state="10" + "0" * num_sys_qubits), qx[:] + ql[:] + [qa[0]])

    ry = RYGate(- np.pi - t2)
    qc.append(ry.control(num_sys_qubits + 2, ctrl_state="01" + "1" * num_sys_qubits), qx[:] + ql[:] + [qa[0]])

    # O_C
    # left shift permutation operators
    x = XGate()
    for i in range(num_sys_qubits, 0, - 1):
        qc.append(x.control(i, ctrl_state="1" * i), [ql[0]] + qx[:i])

    # right shift permutation operators
    x = XGate()
    for i in range(num_sys_qubits, 0, - 1):
        qc.append(x.control(i, ctrl_state="0" * (i - 1) + "1"), [ql[1]] + qx[:i])

    # diffusion operator
    qc.h(ql)
    
    # state preparation
    for k in indices(j):
        qc.x(qx[k])

    if add_measurements:
        qc.measure(qa, ca)
        qc.measure(ql, cl)

    return qc


def signal_oracle(alpha, beta, gamma, num_sys_qubits, i=0, j=0, add_measurements=False, rep=1):
    # Lemma 10 of "Hamiltonian Simulation by Qubitization", Quantum 3, 163 (2019).
    u = block_encoding(alpha, beta, gamma, num_sys_qubits, i=0, j=0, add_measurements=False)
    num_aux_qubits = 2

    # initialise quantum registers
    qf = QuantumRegister(size=1, name="f")
    qa = QuantumRegister(size=1, name="a")
    ql = QuantumRegister(size=num_aux_qubits, name="l")

    # qubits representing |b> and solution |x>
    qx = QuantumRegister(size=num_sys_qubits, name="x")

    w = QuantumCircuit(qf, qa, ql, qx, name="$V_A$")

    # state preparation
    for k in indices(i):
        w.x(qx[k])

    for _ in range(rep):
        w.h(qf)
        # v1
        v1 = u.to_gate().control(num_ctrl_qubits=1, ctrl_state="0")
        w.append(v1, qf[:] + qa[:] + ql[:] + qx[:])

        # v2
        v2 = u.to_gate().inverse().control(num_ctrl_qubits=1, ctrl_state="1")
        w.append(v2, qf[:] + qa[:] + ql[:] + qx[:])

        w.x(qf)
        w.h(qf)

    for k in indices(j):
        w.x(qx[k])

    return w


def unitary_iterate(alpha, beta, gamma, num_sys_qubits, global_phase=0, i=0, j=0, add_measurements=False, rep=1):
    # Lemma 10 of "Hamiltonian Simulation by Qubitization", Quantum 3, 163 (2019).
    num_aux_qubits = 2

    # initialise quantum registers
    qf = QuantumRegister(size=1, name="f")
    qa = QuantumRegister(size=1, name="a")
    ql = QuantumRegister(size=num_aux_qubits, name="l")
    qr = QuantumRegister(size=1, name="r")

    # qubits representing |b> and solution |x>
    qx = QuantumRegister(size=num_sys_qubits, name="x")

    w = QuantumCircuit(qf, qa, ql, qr, qx, name="W", global_phase=global_phase)

    # state preparation
    for k in indices(i):
        w.x(qx[k])

    u = signal_oracle(alpha, beta, gamma, num_sys_qubits, i=0, j=0, add_measurements=False, rep=1)
    w.append(u, qf[:] + qa[:] + ql[:] + qx[:])

    # reflection by Z
    ccccx = XGate().control(num_aux_qubits + 2, ctrl_state="0" * (num_aux_qubits + 2))
    w.append(ccccx, qf[:] + qa[:] + ql[:] + qr[:])
    w.z(qr)
    w.append(ccccx, qf[:] + qa[:] + ql[:] + qr[:])

    for k in indices(j):
        w.x(qx[k])

    return w
