from qiskit import Aer, AncillaRegister, ClassicalRegister, QuantumRegister
from qiskit.circuit import QuantumCircuit

from banded_circulant_matrix import indices


def dilation(block_unitary, i=0, j=0, add_measurements=False):
    # log(s)
    num_aux_qubits = block_unitary.num_ancillas
    num_sys_qubits = block_unitary.num_qubits - num_aux_qubits

    # initialise quantum registers
    ql = AncillaRegister(size=num_aux_qubits, name="l")
    qa = AncillaRegister(size=1, name="a")

    # qubits representing |b> and solution |x>
    qx = QuantumRegister(size=num_sys_qubits, name="x")

    # initialise the quantum circuit
    if add_measurements:
        ca = ClassicalRegister(size=1, name="ca")
        cl = ClassicalRegister(size=num_aux_qubits, name="cl")
        qc = QuantumCircuit(ql, qx, qa, ca, cl, name="$U_A$")
    else:
        qc = QuantumCircuit(ql, qx, qa, name="$U_A$")
    
    # state preparation
    for k in indices(i):
        if k < num_sys_qubits:
            qc.x(qx[k])
        else: 
            qc.x(qa)
    
    u = block_unitary.to_gate()
    qc.append(u.control(1, ctrl_state="1"), qa[:] + ql[:] + qx[:])
    qc.x(qa)
    qc.append(u.inverse().control(1, ctrl_state="1"), qa[:] + ql[:] + qx[:])

    return qc
