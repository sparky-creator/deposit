import numpy as np

from qiskit import Aer, ClassicalRegister, QuantumRegister, transpile
from qiskit.circuit import QuantumCircuit
from qiskit.circuit.library import RYGate
from qiskit.quantum_info import Operator, Statevector


def single_ancilla_qsp_circuit(ref_state, iterate, angles, add_measurements=False):
    # initialise quantum registers
    num_sys_qubits = ref_state.num_qubits
    num_ancilla_qubits = iterate.num_qubits - num_sys_qubits

    # initialise quantum registers
    qr = QuantumRegister(size=1, name="q")
    qa = QuantumRegister(size=num_ancilla_qubits, name="a")
    
    # qubits representing |b>
    qx = QuantumRegister(size=num_sys_qubits, name="x")

    # initialise the quantum circuit
    if add_measurements:
        cr = ClassicalRegister(size=1, name="m")
        ca = ClassicalRegister(size=num_ancilla_qubits, name="c")
        cx = ClassicalRegister(size=num_sys_qubits, name="s")
        qc = QuantumCircuit(qr, qa, qx, cr, ca, cx, name="QSP")
    else:
        qc = QuantumCircuit(qr, qa, qx, name="QSP")

    # |b>
    qc.append(ref_state, qx[:])
    qc.barrier()

    qc.rx(- 2 * angles[-1], qr)
    
    # QSP
    ctrl_w = iterate.to_gate().control(num_ctrl_qubits=1, ctrl_state="1")
    ctrl_w_dg = iterate.inverse().to_gate().control(num_ctrl_qubits=1, ctrl_state="1")

    for i, a in enumerate(reversed(angles[1:-1])):
        if i % 2 == 0:
            qc.append(ctrl_w, qr[:] + qa[:] + qx[:])
            qc.rx(- 2 * a + np.pi, qr)
        else:
            qc.append(ctrl_w_dg, qr[:] + qa[:] + qx[:])
            qc.rx(- 2 * a - np.pi, qr)

    if len(angles) % 2 == 0:
        qc.append(ctrl_w, qr[:] + qa[:] + qx[:])
        qc.rx(- 2 * angles[0], qr)
    else:
        qc.append(ctrl_w_dg, qr[:] + qa[:] + qx[:])
        qc.rx(- 2 * angles[0] - np.pi, qr)
    
    if add_measurements:
        qc.barrier()
        qc.measure(qr, cr)
        qc.measure(qa, ca)
        qc.measure(qx, cx)
    
    return qc

   
def hadamard_test_circuit(ref_state, iterate, add_measurements=False):
    # initialise quantum registers
    num_sys_qubits = ref_state.num_qubits
    num_ancilla_qubits = iterate.num_qubits - num_sys_qubits

    # initialise quantum registers
    qr = QuantumRegister(size=1, name="q")
    cr = ClassicalRegister(size=1, name="m")
    qa = QuantumRegister(size=num_ancilla_qubits, name="a")
    ca = ClassicalRegister(size=num_ancilla_qubits, name="c")
    # qubits representing |b>
    qx = QuantumRegister(size=num_sys_qubits, name="x")
    cx = ClassicalRegister(size=num_sys_qubits, name="s")

    # initialise the quantum circuit
    qc = QuantumCircuit(qr, qa, qx, cr, ca, cx, name="QSP")

    # |b>
    qc.append(ref_state, qx[:])

    # |+>
    qc.h(qr)
    
    # QSP
    ctrl_w = iterate.to_gate().control(num_ctrl_qubits=1, ctrl_state="1")
    qc.append(ctrl_w, qr[:] + qa[:] + qx[:])

    # |+>
    qc.s(qr)
    qc.h(qr)
    qc.barrier()

    if add_measurements:
        qc.measure(qr, cr)
        qc.measure(qa, ca)
        qc.measure(qx, cx)
    
    return qc
