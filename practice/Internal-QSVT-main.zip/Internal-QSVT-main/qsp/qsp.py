import numpy as np

from qiskit import Aer, ClassicalRegister, execute, QuantumRegister, transpile
from qiskit.circuit import QuantumCircuit
from qiskit.circuit.library import RYGate
from qiskit.quantum_info import Operator, Statevector


# matrix
def W(x):
    return np.matrix(
        [
            [x, 1j * np.sqrt(1 - x ** 2)], 
            [1j * np.sqrt(1 - x ** 2), x],
        ]
    )
                   

def R(x):
    return np.matrix(
        [
            [x, np.sqrt(1 - x ** 2)], 
            [np.sqrt(1 - x ** 2), - x],
        ]
    )


def RZ(theta):
    return np.matrix(
        [
            [np.exp(1j * theta), 0], 
            [0, np.exp(- 1j * theta)],
        ]
    )


def Poly(W, phases):
    M = RZ(phases[0])
    
    for phi in phases[1:]:
        M *= W * RZ(phi)
    
    return M


def expectation(v, M):
    return np.conjugate(v) @ M @ v


def to_single_ancilla_qsp_angles(ancilla_free_qsp_angles):
    sa_angles = np.zeros(2 * len(ancilla_free_qsp_angles) - 1)
    for i, v in enumerate(ancilla_free_qsp_angles):
        sa_angles[2 * i] = v

    return sa_angles


# quantum circuit
def ancilla_free_qsp_circuit(t, angles, basis="Z", add_measurements=False):
    # initialise quantum registers
    qr = QuantumRegister(size=1, name="q")
    # initialise the quantum circuit
    if add_measurements:
        cr = ClassicalRegister(size=1, name="c")
        qc = QuantumCircuit(qr, cr)
    else:
        qc = QuantumCircuit(qr)

    if basis == "X":
        # |+>
        qc.h(qr)

    # QSP
    qc.rz(- 2 * angles[-1], qr)
    for a in reversed(angles[:-1]):
        qc.rx(- t, qr)
        qc.rz(- 2 * a, qr)

    if basis == "X":
        # |+>
        qc.h(qr)

    if add_measurements:
        qc.measure(qr, cr)

    return qc


def run_ancilla_free_qsp(t, angles, basis="Z", simulator="qasm_simulator", shots=1024):
    if simulator == "qasm_simulator":
        qc = ancilla_free_qsp_circuit(t, angles, basis=basis, add_measurements=True)
        backend = Aer.get_backend("qasm_simulator")
        job = backend.run(transpile(qc, backend), shots=shots)
        result = job.result()
        counts = result.get_counts(qc)
        keys = counts.keys()
        return counts["0"] / shots if "0" in keys else 1
    elif simulator == "aer_simulator_statevector":
        backend = Aer.get_backend("aer_simulator_statevector")
        backend.set_options(precision="double")
        qc = ancilla_free_qsp_circuit(t, angles, basis=basis, add_measurements=False)
        qc = transpile(qc, backend=backend)
        qc.save_statevector()
        job = backend.run(qc)
        sv = job.result().get_statevector(qc)
        p = sv.probabilities_dict()
        return p["0"]
    elif simulator == "unitary_simulator":
        qc = ancilla_free_qsp_circuit(t, angles, basis=basis, add_measurements=False)
        backend = Aer.get_backend("unitary_simulator")
        job = execute(qc, backend)
        result = job.result()
        return result.get_unitary(qc, decimals=3)
    else:
        return None


def single_ancilla_qsp_circuit(t, angles, add_measurements=False):
    # initialise quantum registers
    qr = QuantumRegister(size=1, name="q")
    cr = ClassicalRegister(size=1, name="c")
    qs = QuantumRegister(size=1, name="s")
    # initialise the quantum circuit
    qc = QuantumCircuit(qr, qs, cr)
    
    # |b> = |+i>
    qc.h(qs)
    qc.s(qs)
    qc.barrier()

    qc.rx(- 2 * angles[-1], qr)
    
    # QSP    
    for i, a in enumerate(reversed(angles[1:-1])):
        if i % 2 == 0:
            qc.cry(- 2 * t, qr, qs)
            qc.rx(- 2 * a + np.pi, qr)
        else:
            qc.cry(2 * t, qr, qs)
            qc.rx(- 2 * a - np.pi, qr)

    if len(angles) % 2 == 0:
        qc.cry(- 2 * t, qr, qs)
        qc.rx(- 2 * angles[0], qr)
    else:
        qc.cry(2 * t, qr, qs)
        qc.rx(- 2 * angles[0] - np.pi, qr)

    if add_measurements:
        qc.barrier()
        qc.measure(qr, cr)
    
    return qc


def run_single_ancilla_qsp(t, angles, simulator="qasm_simulator", shots=1024):
    if simulator == "qasm_simulator":
        qc = single_ancilla_qsp_circuit(t, angles, add_measurements=True)
        backend = Aer.get_backend("qasm_simulator")
        job = backend.run(transpile(qc, backend), shots=shots)
        result = job.result()
        counts = result.get_counts(qc)
        keys = counts.keys()
        return counts["0"] / shots if "0" in keys else 1
    elif simulator == "aer_simulator_statevector":
        qc = single_ancilla_qsp_circuit(t, angles, add_measurements=False)
        qc = transpile(qc, basis_gates=["rz", "sx", "cx"])
        backend = Aer.get_backend("aer_simulator_statevector")
        backend.set_options(precision="double")
        qc.save_statevector()
        job = backend.run(qc)
        sv = job.result().get_statevector(qc)
        p = sv.probabilities_dict()
        return p["00"] + p["10"] 
    else:
        return None


def lcu_circuit(t, angles1, angles2, add_measurements=False):
    # initialise quantum registers
    qr = QuantumRegister(size=1, name="q")
    qa1 = QuantumRegister(size=1, name="a1")
    qa2 = QuantumRegister(size=1, name="a2")
    cr = ClassicalRegister(size=1, name="c")
    ca1 = ClassicalRegister(size=1, name="c1")
    ca2 = ClassicalRegister(size=1, name="c2")
    qs = QuantumRegister(size=1, name="s")
    # initialise the quantum circuit
    qc = QuantumCircuit(qr, qa1, qa2, qs, cr, ca1, ca2)

    # |+>
    qc.h(qr)

    # |b> = |+i>
    qc.h(qs)
    qc.s(qs)
    qc.barrier()

    # QSP   
    qc.crx(- 2 * angles1[-1], qr, qa1, ctrl_state="0")
    
    for i, a in enumerate(reversed(angles1[1:-1])):
        if i % 2 == 0:
            ry = RYGate(- 2 * t)
            ccry = ry.control(num_ctrl_qubits=2, ctrl_state="10")
            qc.append(ccry, qr[:] + qa1[:] + qs[:])
            qc.crx(- 2 * a + np.pi, qr, qa1, ctrl_state="0")
        else:
            ry = RYGate(2 * t)
            ccry = ry.control(num_ctrl_qubits=2, ctrl_state="10")
            qc.append(ccry, qr[:] + qa1[:] + qs[:])
            qc.crx(- 2 * a - np.pi, qr, qa1, ctrl_state="0")

    if len(angles1) % 2 == 0:
        ry = RYGate(- 2 * t)
        ccry = ry.control(num_ctrl_qubits=2, ctrl_state="10")
        qc.append(ccry, qr[:] + qa1[:] + qs[:])
        qc.crx(- 2 * angles1[0], qr, qa1, ctrl_state="0")
        qc.p(0.5 * t, qr)
    else:
        ry = RYGate(2 * t)
        ccry = ry.control(num_ctrl_qubits=2, ctrl_state="10")
        qc.append(ccry, qr[:] + qa1[:] + qs[:])
        qc.crx(- 2 * angles1[0] - np.pi, qr, qa1, ctrl_state="0")

    # QSP   
    qc.crx(- 2 * angles2[-1], qr, qa2, ctrl_state="1")
    
    for i, a in enumerate(reversed(angles2[1:-1])):
        if i % 2 == 0:
            ry = RYGate(- 2 * t)
            ccry = ry.control(num_ctrl_qubits=2, ctrl_state="11")
            qc.append(ccry, qr[:] + qa2[:] + qs[:])
            qc.crx(- 2 * a + np.pi, qr, qa2, ctrl_state="1")
        else:
            ry = RYGate(2 * t)
            ccry = ry.control(num_ctrl_qubits=2, ctrl_state="11")
            qc.append(ccry, qr[:] + qa2[:] + qs[:])
            qc.crx(- 2 * a - np.pi, qr, qa2, ctrl_state="1")

    if len(angles2) % 2 == 0:
        ry = RYGate(- 2 * t)
        ccry = ry.control(num_ctrl_qubits=2, ctrl_state="11")
        qc.append(ccry, qr[:] + qa2[:] + qs[:])
        qc.crx(- 2 * angles2[0], qr, qa2, ctrl_state="1")
        qc.p(- 0.5 * t, qr)
    else:
        ry = RYGate(2 * t)
        ccry = ry.control(num_ctrl_qubits=2, ctrl_state="11")
        qc.append(ccry, qr[:] + qa2[:] + qs[:])
        qc.crx(- 2 * angles2[0] - np.pi, qr, qa2, ctrl_state="1")

    # |+>
    qc.h(qr)

    if add_measurements:
        qc.barrier()
        qc.measure(qr, cr)
        qc.measure(qa1, ca1)
        qc.measure(qa2, ca2)
    
    return qc


def run_lcu(t, angles1, angles2, simulator="qasm_simulator", shots=1024):
    if simulator == "qasm_simulator":
        qc = lcu_circuit(t, angles1, angles2, add_measurements=True)
        backend = Aer.get_backend("qasm_simulator")
        job = backend.run(transpile(qc, backend), shots=shots)
        result = job.result()
        counts = result.get_counts(qc)
        keys = counts.keys()
        return counts["000"] / shots if "0" in keys else 1
    elif simulator == "aer_simulator_statevector":
        qc = lcu_circuit(t, angles1, angles2, add_measurements=False)
        qc = transpile(qc, basis_gates=["rz", "sx", "cx"])
        backend = Aer.get_backend("aer_simulator_statevector")
        backend.set_options(precision="double")
        qc.save_statevector()
        job = backend.run(qc)
        sv = job.result().get_statevector(qc)
        p = sv.probabilities_dict()
        return p["0000"] + p["1000"]
    else:
        return None
