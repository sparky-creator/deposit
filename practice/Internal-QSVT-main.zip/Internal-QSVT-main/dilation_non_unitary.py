#see:https://arxiv.org/pdf/2205.02826.pdf

def get_dilated(D):
    
    "gets unitary version of D as descibed in the paper"
    plus_list = []
    minus_list = []
    
    for elem in D:
        plus_list.append(elem + 1.0j * np.sqrt(1/elem ** 2 - 1) * elem)
        minus_list.append(elem - 1.0j * np.sqrt(1/elem ** 2 - 1) * elem)
        
    Z = np.zeros((4,4),dtype=int) # Create off-diagonal zeros array
    dilated_D = np.asarray(np.bmat([[np.diag(plus_list), Z], 
                        [Z, np.diag(minus_list)]]))

    return dilated_D

def B_circuit(B_num, nqubits):
    
    #SVD 
    U, D, Vdag = np.linalg.svd(B_num)
    Uop = Operator(U)
    Vdag_op = Operator(Vdag)
    D = D/np.max(D) #for the scheme to work we need all elements of D to be less than or equal to one, 
    #such a scaling would only affect the success probability

    dilated_D = get_dilated(D)

    qc = QuantumCircuit(nqubits+2)
    qc.append(Vdag_op, [2, 3])
    qc.h(1)
    qc.append(Operator(dilated_D), [1, 2, 3])
    qc.h(1)
    qc.append(Uop, [2, 3])
    
    return qc

B_circuit(B_num, nqubits=2).draw('mpl')