from qiskit_optimization.problems.variable import VarType
from copy import deepcopy
from qiskit_optimization.algorithms import CplexOptimizer, OptimizationResult
from qiskit_optimization.problems.constraint import ConstraintSense
from qiskit_optimization import QuadraticProgram
import numpy as np

def generate_cut_problem(qp: QuadraticProgram) -> QuadraticProgram:
    # Check the model is MIP
    assert qp.get_num_quadratic_constraints() == 0
    assert len(qp.objective.quadratic.to_dict()) == 0

    # Convert qp into mip.Model
    from mip import Model, xsum, BINARY, CONTINUOUS, maximize, minimize, CutType
    model = Model()

    var_list = [model.add_var(v.name, v.lowerbound, v.upperbound, var_type=BINARY if v.vartype==VarType.BINARY else CONTINUOUS) for v in qp.variables]
    
    c_obj = qp.objective.linear.to_array()
    if qp.objective.sense.name == 'MINIMIZE':
        model.objective = minimize(xsum(c_obj[j]*v for j, v in enumerate(var_list)))
    else:
        model.objective = maximize(xsum(c_obj[j]*v for j, v in enumerate(var_list)))

    for l_const_info in qp.linear_constraints:
        a = l_const_info.linear.to_array()
        b = l_const_info.rhs
        sense = l_const_info.sense.label
        if sense == '<=':
            model += xsum(a[j]*v for j, v in enumerate(var_list)) <= b
        elif sense == '>=':
            model += xsum(a[j]*v for j, v in enumerate(var_list)) >= b
        else:
            model += xsum(a[j]*v for j, v in enumerate(var_list)) == b

    model.optimize(relax=True)
    cp = model.generate_cuts(cut_types=[
        CutType.GOMORY, 
        #CutType.KNAPSACK_COVER,
        #CutType.CLIQUE, 
        ])

    # Define qp with cuts
    qp_cuts = deepcopy(qp)
    for cut in cp.cuts:
        assert cut.sense == '<'
        qp_cuts.linear_constraint([cut.expr[v] if v in cut.expr else 0 for v in var_list], rhs=-cut.const)

    return qp_cuts


def solve_relaxed(qp: QuadraticProgram) -> OptimizationResult:
    qp_relaxed = deepcopy(qp)

    for var in qp_relaxed.variables:
        if var.vartype == VarType.BINARY:
            var.vartype = VarType.CONTINUOUS
            var.lowerbound = 0
            var.upperbound = 1

    # for constr in qp_relaxed.linear_constraints:
    #     qp_relaxed.linear_constraints.remove(constr)
    # print(qp_relaxed.prettyprint())
    cplex_result = CplexOptimizer().solve(qp_relaxed)
    print(cplex_result.prettyprint())
    return cplex_result


def print_solution_summary(qp: QuadraticProgram, result: OptimizationResult, label=''):
    x_sol = result.x
    n_bin = qp.get_num_binary_vars()

    np.set_printoptions(formatter={'float': '{:.3f}'.format})
    print(
            '-'*100,
            f'[{label} Result]',
            f'   optimal value: {result.fval:.3f}',
            f'   optimal solution (binary): {x_sol[:n_bin].astype(int)}',
            f'   optimal solution (continuous): {x_sol[n_bin:]}',
            f'   status: {result.status.name}',
            '-'*100,
            sep='\n'
        )

def print_problem_summary(qp: QuadraticProgram):
    n_bin_vars = qp.get_num_binary_vars()
    n_cont_vars = qp.get_num_continuous_vars()
    n_eq = len([c for c in qp.linear_constraints if c.sense == ConstraintSense.EQ])
    n_le = len([c for c in qp.linear_constraints if c.sense == ConstraintSense.LE])
    n_ge = len([c for c in qp.linear_constraints if c.sense == ConstraintSense.GE])

    print(
            '-'*50,
            '[Problem Information]',
            '- Decision Variables',
            f'   number of binary vars: {n_bin_vars}',
            f'   number of continuous vars: {n_cont_vars}',
            '- Linear Constraints',
            f'   number of eq constraints: {n_eq}',
            f'   number of le constraints: {n_le}',
            f'   number of ge constraints: {n_ge}',
            '-'*50,
            sep='\n'
        )
                