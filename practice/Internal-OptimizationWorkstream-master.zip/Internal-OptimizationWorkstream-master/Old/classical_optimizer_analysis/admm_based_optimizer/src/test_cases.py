from qiskit_optimization import QuadraticProgram

def get_case_1() -> QuadraticProgram:
    from qiskit_optimization.translators import from_docplex_mp
    from docplex.mp.model import Model

    mdl = Model("ex6")

    v = mdl.binary_var(name="v")
    w = mdl.binary_var(name="w")
    t = mdl.binary_var(name="t")
    u = mdl.continuous_var(name="u")

    mdl.minimize(v + w + t + 5 * (u - 2) ** 2)
    mdl.add_constraint(v + 2 * w + t + u <= 3, "cons1")
    mdl.add_constraint(v + w + t >= 1, "cons2")
    mdl.add_constraint(v + w == 1, "cons3")

    # load quadratic program from docplex model
    qp = from_docplex_mp(mdl)
    return qp



def get_case_2() -> QuadraticProgram:
    import numpy as np
    from itertools import product
    num_J = 3
    num_M = 3

    d_order = np.array([
        [2, 1, 2],
        [0, 2, 1],
        [1, 0, 0]
        ]).astype(int)

    d_time = np.array([
        [2, 1, 1],
        [1, 2, 2],
        [2, 2, 1]
        ])

    mdl = QuadraticProgram('JSP')

    # binary variables
    for i,j,k in product(range(num_M), range(num_J), range(num_J)):
        if j>=k: continue
        mdl.binary_var(name=f'x({i},{j},{k})')

    # maximum makespan
    C_max = sum(d_time[i,j] for i,j in product(range(num_M), range(num_J)))

    # continuous variables
    mdl.continuous_var(lowerbound=0, name='C')
    for i,j in product(range(num_M), range(num_J)):
        mdl.continuous_var(lowerbound=0, name=f'y({i},{j})')

    # objective function
    mdl.minimize(linear = {'C':1})

    # ge constraints 1
    for i,j in product(range(1, num_M), range(num_J)):
        mdl.linear_constraint(
            linear = {f'y({d_order[i-1,j]},{j})':-1, f'y({d_order[i,j]},{j})':1}, 
            sense = '>=', 
            rhs = d_time[d_order[i-1,j], j]
            )
        
    # ge constraints 2
    for i,j,k in product(range(num_M), range(num_J), range(num_J)):
        if j>=k: continue
        mdl.linear_constraint(
            linear = {f'y({i},{j})':1, f'y({i},{k})':-1, f'x({i},{j},{k})':C_max}, 
            sense = '>=', 
            rhs = d_time[i,k]
            )
        mdl.linear_constraint(
            linear = {f'y({i},{j})':-1, f'y({i},{k})':1, f'x({i},{j},{k})':-C_max}, 
            sense = '>=', 
            rhs = -C_max + d_time[i,j]
            )

    # ge constraints 3
    for j in range(num_J):
        mdl.linear_constraint(
            linear = {'C':1, f'y({d_order[-1,j]},{j})':-1}, 
            sense = '>=', 
            rhs = d_time[d_order[-1,j], j]
            )
    
    return mdl