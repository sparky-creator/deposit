from qiskit_optimization import QuadraticProgram
from qiskit_optimization.algorithms import CplexOptimizer
from qiskit_optimization.algorithms import OptimizationResult, OptimizationResultStatus

import numpy as np 
from scipy.sparse import dok_matrix, identity
import pandas as pd
import matplotlib.pyplot as plt

class ADMM_basics():

    def __init__(self, model):
        self.mdl = model

        # count of each variables
        self.n_all_vars = model.get_num_vars()
        self.n_bin_vars = model.get_num_binary_vars()
        self.n_cont_vars = model.get_num_continuous_vars()
        self.n_slack_vars = 0
        self.n_pos = self.n_cont_vars
        
        # count of each constraints
        self.n_lin_const = model.get_num_linear_constraints()
        self.n_eq = 0
        self.n_le = 0
        self.n_ge = 0

        # initialize algebraic form of objective function
        self.c = None
        self.c_bin = None
        self.c_cont = None
        self.Q = None
        self.Q_bin = None
        self.Q_cont = None
        self.constant = model.objective.constant

        # initialize algebraic form of linear constraints
        self.a_bin = None
        self.a_cont = None
        self.b = None

        # setup of algebraic form
        self.admm_setup()
        self.A_bin = self.a_bin.T @ self.a_bin
        self.A_cont = self.a_cont.T @ self.a_cont

        # variables for admm
        self.q = np.zeros(self.n_bin_vars)
        self.u = np.zeros(self.n_pos)
        self.x = np.zeros(self.n_all_vars)
        self.lam = np.zeros(self.n_lin_const)
        self.rho = 0
        self.fval = 0
        self.status = 1
    
    def admm_setup(self):
        a_eq_bin = dok_matrix((0, self.n_bin_vars))
        a_eq_cont = dok_matrix((0, self.n_cont_vars))
        b_eq = np.empty(0)

        a_le_bin = dok_matrix((0, self.n_bin_vars))
        a_le_cont = dok_matrix((0, self.n_cont_vars))
        b_le = np.empty(0)

        a_ge_bin = dok_matrix((0, self.n_bin_vars))
        a_ge_cont = dok_matrix((0, self.n_cont_vars))
        b_ge = np.empty(0)

        self.bound = []

        for idx in range(self.n_lin_const):
            const_info = self.mdl.get_linear_constraint(idx)
            a = dok_matrix(const_info.linear.to_array().reshape((1,-1)))
            a_bin = a[0, :self.n_bin_vars]
            a_cont = a[0, self.n_bin_vars:]
            sense = const_info.sense.name
            b = const_info.rhs
            
            if sense == 'EQ':
                self.n_eq += 1
                a_eq_bin._shape = (self.n_eq, self.n_bin_vars)
                a_eq_bin[-1] = dok_matrix(a_bin)
                a_eq_cont._shape = (self.n_eq, self.n_cont_vars)
                a_eq_cont[-1] = dok_matrix(a_cont)
                b_eq = np.append(b_eq, b)
            
            elif sense == 'LE':
                self.n_le += 1
                a_le_bin._shape = (self.n_le, self.n_bin_vars)
                a_le_bin[-1] = dok_matrix(a_bin)
                a_le_cont._shape = (self.n_le, self.n_cont_vars)
                a_le_cont[-1] = dok_matrix(a_cont)
                b_le = np.append(b_le, b)

                # m = QuadraticProgram('RHS')
                # for i in range(self.n_bin_vars):
                #     m.binary_var(name = f'x_{i}')
                # for k in range(self.n_cont_vars):
                #     var_info = self.mdl.variables[self.n_bin_vars + k]
                #     m.continuous_var(
                #         lowerbound=var_info.lowerbound,
                #         upperbound=var_info.upperbound,
                #         name=f'y_{k}')
                # m.maximize(linear=-a, constant=b)
                # result = CplexOptimizer().solve(m)
                # if result.fval > 0:
                #     self.bound.append(result.fval)
                # else:
                #     self.bound.append(float('inf'))
                self.bound.append(float('inf'))
            
            elif sense == 'GE':
                self.n_ge += 1
                a_ge_bin._shape = (self.n_ge, self.n_bin_vars)
                a_ge_bin[-1] = dok_matrix(a_bin)
                a_ge_cont._shape = (self.n_ge, self.n_cont_vars)
                a_ge_cont[-1] = dok_matrix(a_cont)
                b_ge = np.append(b_ge, b)

                # m = QuadraticProgram('LHS')
                # for i in range(self.n_bin_vars):
                #     m.binary_var(name = f'x_{i}')
                # for k in range(self.n_cont_vars):
                #     var_info = self.mdl.variables[self.n_bin_vars + k]
                #     m.continuous_var(
                #         lowerbound=var_info.lowerbound,
                #         upperbound=var_info.upperbound,
                #         name=f'y_{k}')
                # m.maximize(linear=a, constant=-b)
                # result = CplexOptimizer().solve(m)
                # if result.fval > 0:
                #     self.bound.append(result.fval)
                # else:
                #     self.bound.append(float('inf'))
                self.bound.append(float('inf'))
        
        l0, l1 = self.n_eq, self.n_eq + self.n_le
        
        self.a_bin = dok_matrix((self.n_lin_const, self.n_bin_vars))
        self.a_bin[:l0, :] = a_eq_bin
        self.a_bin[l0:l1, :] = a_le_bin
        self.a_bin[l1:, :] = a_ge_bin
        
        self.b = np.empty(0)
        self.b = np.append(self.b, b_eq)
        self.b = np.append(self.b, b_le)
        self.b = np.append(self.b, b_ge)

        self.n_slack_vars += self.n_le + self.n_ge
        self.n_pos += self.n_slack_vars

        self.a_cont = dok_matrix((self.n_lin_const, self.n_pos))
        if self.n_eq > 0:
            self.a_cont[:l0, :self.n_cont_vars] = a_eq_cont
        if self.n_le > 0:
            self.a_cont[l0:l1, :self.n_cont_vars] = a_le_cont
            self.a_cont[l0:l1, self.n_cont_vars:self.n_cont_vars+self.n_le] = identity(self.n_le, format='dok')
        if self.n_ge > 0:
            self.a_cont[l1:, :self.n_cont_vars] = a_ge_cont
            self.a_cont[l1:, self.n_cont_vars+self.n_le:] = -identity(self.n_ge, format='dok')
        
        self.a_bin = self.a_bin.tocsr()
        self.a_cont = self.a_cont.tocsr()

        self.c = self.mdl.objective.linear.to_array()
        self.Q = self.mdl.objective.quadratic.coefficients.tocsr()
        if self.mdl.objective.sense.name == 'MAXIMIZE':
            self.c = -self.c
            self.Q = -self.Q
        self.c_bin = self.c[:self.n_bin_vars]
        self.c_cont = np.concatenate((self.c[self.n_bin_vars:], np.zeros(self.n_slack_vars)))
        self.Q_bin = self.Q[:self.n_bin_vars, :self.n_bin_vars]
        #self.Q_cont = self.Q[self.n_bin_vars:, self.n_bin_vars:]
        #self.Q_cont._shape = (self.n_pos, self.n_pos)

    def update_bin_vars_quantum(self):
        return None

    def update_bin_vars_classical(self):
        qp = QuadraticProgram('admm bin')

        for k in range(self.n_bin_vars):
            qp.binary_var(name=f'q_{k}')

        qp.minimize(
            linear = self.c_bin - self.lam@self.a_bin - self.rho*(self.b-self.a_cont@self.u)@self.a_bin,
            quadratic = self.Q_bin + (self.rho/2)*self.A_bin
            )
        
        result = CplexOptimizer().solve(qp)
        self.q = result.x.astype(int)

    def update_cont_vars(self):
        qp = QuadraticProgram('admm cont')

        for k in range(self.n_cont_vars):
            var_info = self.mdl.variables[self.n_bin_vars + k]
            qp.continuous_var(
                lowerbound=var_info.lowerbound,
                upperbound=var_info.upperbound,
                name=f'u_{k}')
        
        for k in range(self.n_cont_vars, self.n_pos):
            qp.continuous_var(
                lowerbound=0, 
                upperbound=self.bound[k - self.n_cont_vars],
                name=f'u_{k}')
        
        #for k in range(self.n_pos):
        #    qp.continuous_var(lowerbound=0, name=f'u_{k}')

        qp.minimize(
            linear = self.c_cont - self.lam@self.a_cont - self.rho*(self.b-self.a_bin@self.q)@self.a_cont,
            quadratic = (self.rho/2)*self.A_cont
            )
        
        result = CplexOptimizer().solve(qp)
        self.u = result.x

    def update_Lagrange_multiplier(self):
        self.lam = self.lam + self.rho*(self.b - self.a_bin@self.q - self.a_cont@self.u)
    
    def update_solution(self):
        self.x[:self.n_bin_vars] = self.q
        self.x[self.n_bin_vars:] = self.u[:self.n_cont_vars]

    def calc_obj_val(self):
        self.fval = self.x@self.Q@self.x + self.c@self.x + self.constant
    
    def check_feasibility(self):
        if self.mdl.get_feasibility_info(self.x)[0]:
            self.status = ['feasible', 0]
        else:
            self.status = ['infeasible', 2]
    
    def draw(self, exact_val, fig_size, font_size):
        plt.rcParams['font.family'] = 'Times New Roman'
        plt.rcParams['font.size'] = font_size
        plt.rcParams["figure.figsize"] = fig_size

        plt.hlines(exact_val, -1, len(self.opt_record.index), colors='gray', zorder=1, linestyle='dashed', label='optimal value')

        Y_data = self.opt_record.loc[:,'objective function value'].to_numpy()
        X_data = np.arange(len(Y_data))
        plt.plot(X_data, Y_data, color='royalblue', zorder=2)

        X_0, Y_0 = [], []
        X_1, Y_1 = [], []
        for k in range(len(Y_data)):
            if self.opt_record.loc[f'step {k}', 'status'] == 'feasible':
                X_1 = np.append(X_1, X_data[k])
                Y_1 = np.append(Y_1, Y_data[k])
            else:
                X_0 = np.append(X_0, X_data[k])
                Y_0 = np.append(Y_0, Y_data[k])

        plt.scatter(X_1, Y_1, c='deepskyblue', s=100, zorder=3, label=('feasible'))
        plt.scatter(X_0, Y_0, c='indianred', s=100, zorder=3, label='infeasible')

        plt.xlim(-0.2, len(Y_data)-0.8)

        plt.xticks(np.array([k for k in range(0, len(Y_data), 1)]))
        plt.yticks([exact_val])

        plt.title(f'Optimization Result')
        plt.xlabel('Optimization Steps')
        plt.ylabel('Objective Function Value')

        plt.legend(bbox_to_anchor=(1, 0), loc='lower right', borderaxespad=1, fontsize='medium')

        plt.show()

class ADMMxGNQA_Optimizer(ADMM_basics):
    
    def __init__(self, mdl):
        super().__init__(mdl)

        self.opt_record = None

    def solve(self, step_max, x_ini, lam_ini, rho, gnqa_step_max, filter_function, Omega, epsiron):
        self.x = x_ini
        self.q = x_ini[:self.n_bin_vars]
        self.u[:self.n_cont_vars] = x_ini[self.n_bin_vars:]
        self.lam = lam_ini
        self.rho = rho
        super().calc_obj_val()
        super().check_feasibility()

        self.opt_record = pd.DataFrame({
            'objective function value': self.fval,
            'status': self.status[0]},
            index=[f'step {0}'])

        for step in range(step_max):
            super().update_cont_vars()
            super().update_bin_vars_gnqa(gnqa_step_max, filter_function, Omega, epsiron)
            super().update_Lagrange_multiplier()
            super().update_solution()
            super().calc_obj_val()
            super().check_feasibility()
            self.opt_record.loc[f'step {step+1}'] = [self.fval, self.status[0]]

        return OptimizationResult(
                x = self.x,
                fval = self.fval,
                variables = self.mdl.variables,
                raw_results = None,
                status = OptimizationResultStatus(self.status[1])
            )
    
                    
class ADMMxClassical_Optimizer(ADMM_basics):
    
    def __init__(self, mdl):
        super().__init__(mdl)

        self.opt_record = None

    def solve(self, step_max, x_ini, lam_ini, rho):
        self.x = x_ini
        self.q = x_ini[:self.n_bin_vars]
        self.u[:self.n_cont_vars] = x_ini[self.n_bin_vars:]
        self.lam = lam_ini
        self.rho = rho
        super().calc_obj_val()
        super().check_feasibility()

        self.opt_record = pd.DataFrame({
            'objective function value': self.fval,
            'status': self.status[0]},
            index=[f'step {0}'])

        for step in range(step_max):
            super().update_bin_vars_classical()
            super().update_cont_vars()
            super().update_Lagrange_multiplier()
            super().update_solution()
            super().calc_obj_val()
            super().check_feasibility()
            self.opt_record.loc[f'step {step+1}'] = [self.fval, self.status[0]]

        return OptimizationResult(
                x = self.x,
                fval = self.fval,
                variables = self.mdl.variables,
                raw_results = None,
                status = OptimizationResultStatus(self.status[1])
            )
    