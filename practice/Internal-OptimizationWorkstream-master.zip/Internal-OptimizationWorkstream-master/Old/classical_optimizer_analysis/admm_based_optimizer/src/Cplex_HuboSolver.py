from qiskit_optimization import QuadraticProgram
from qiskit_optimization.algorithms import CplexOptimizer, OptimizationResult

class CPLEX_HUBOsolver():

    def __init__(self):
        self.N = None
        self.hubo_terms = None
        self.model = None
    
    def MIP_formulation(self):
        # binary variables
        for i in range(self.N):
            self.model.binary_var(name=f'x({i})')

        # auxiliary variables
        for key, val in self.hubo_terms.items():
            n = len(key)
            if n==1: continue
            idx = ','.join([str(_) for _ in key])
            self.model.binary_var(name=f'x({idx})')

        # le constraints
        obj_linear = {}
        for key, val in self.hubo_terms.items():
            n = len(key)
            if n==1:
                obj_linear[f'x({key[0]})'] = val
            else:
                idx = ','.join([str(_) for _ in key])
                aux_var = f'x({idx})'
                obj_linear[aux_var] = val
                dict_tmp = {aux_var:-1}
                for i in range(n):
                    self.model.linear_constraint(linear={f'x({key[i]})':-1, aux_var:1}, sense='<=', rhs=0)
                    dict_tmp[f'x({key[i]})'] = 1
                self.model.linear_constraint(linear=dict_tmp, sense='<=', rhs=n-1)

        # objective function
        self.model.minimize(linear=obj_linear)
    
    def solve(self, hubo):
        self.N, self.hubo_terms = hubo
        self.model = QuadraticProgram('hubo mip')
        self.MIP_formulation()
        result = CplexOptimizer().solve(self.model)

        return OptimizationResult(
                x = result.x[:self.N].astype(int),
                fval = result.fval,
                variables = result.variables[:self.N],
                status = result.status,
            )