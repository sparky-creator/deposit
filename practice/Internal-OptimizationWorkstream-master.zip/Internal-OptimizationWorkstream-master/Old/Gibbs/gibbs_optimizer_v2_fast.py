import numpy as np
from qiskit.primitives import BaseSamplerV1

class Quantum_Optimizer():

    def __init__(self) -> None:
        pass


    def set_optimizer(self, num_binary_var, ansatz, sampler):
        self.N = num_binary_var
        self.ansatz = ansatz
        self.sampler = sampler


    def calc_expectation(self, theta, objective:callable):
        """
        Runs the parameterized circuit and returns cVAR value
        """

        qc = self.ansatz.copy()
        qc.measure_all()

        if isinstance(self.sampler, BaseSamplerV1):
            job = self.sampler.run(qc, theta)
            result = job.result()
            quasi_dist = result.quasi_dists[0]
            prob_dict = quasi_dist.binary_probabilities()
            nshots = self.sampler.options.shots
            counts = {key: int(round(val * nshots)) for key, val in prob_dict.items()}
        
        else: # SamplerV2
            job = self.sampler.run((qc, theta))
            result = job.result()
            nshots = self.sampler.data.meas.num_shots
            counts = result[0].data.meas.get_counts()

        self.obj_val_sum = 0.0
        entrpy_val_sum = 0.0
        for key, count in counts.items():
            x = np.array(list(key)).astype(int)
            x = np.flip(x)
            obj_val = objective(x)/self.scaling
            
            entrpy_val_sum += (1/self.beta * counts[key]/nshots * np.log2(counts[key]/nshots))
            
            self.obj_val_sum+=(obj_val * counts[key]/nshots)

            if obj_val < self.best_fval:
                self.best_fval = obj_val
                self.best_x = x
                

        return (self.obj_val_sum + entrpy_val_sum)
    

    def NFT_update(self, val0, val1, val2, eps=1e-32):
        """
        Parameter update based on the NFT scheme
        """
        z0, z1, z3 = val0, val1, val2
        z2 = z1 + z3 - z0
        dr = eps * (z0 == z2)
        r = (z1 - z3) / ((z0 - z2) + dr)
        dw = np.arctan(float(r))
        dw += np.pi/2 + np.pi/2 * np.sign((z0 - z2) + dr)
        return dw


    def run(self, objective:callable, qc_params_init, scaling, max_sweep=20, random_update=True, 
            intermediate_result_display=False, refval=None, alpha=1.0, beta=0.1):
        
        """
        Main routine that runs for a fixed number of epochs
        
        """
        
        n_params = len(self.ansatz.parameters)
        theta = qc_params_init

        final_epoch = 0
        final_step = 0
        expec_log = []
        

        self.best_fval = 1e100
        self.best_x = None
        self.obj_val_sum = 0.0
        
        self.alpha = alpha #cVAR param
        self.beta = beta
        self.scaling = scaling

        expval = self.calc_expectation(theta, objective)
        #max_epoch = 1 #fix
        
        isbreak = False
        for _ in range(max_epoch):
            
            if isbreak: break

            if random_update==True:
                idx_set = np.random.permutation(n_params).astype(int)
            else:
                idx_set = np.arange(n_params).astype(int)
            
            isweep = 0
            for j, k in enumerate(idx_set):
                if j==0: pass
                else:
                    expval = self.calc_expectation(theta, objective)

                if isweep > max_sweep: #break after going over few params
                    break
                
                if intermediate_result_display:
                    print(f'epoch {_} \t step {j} \t exp_evals {self.obj_val_sum * scaling} \t best val {self.best_fval*scaling}')

                isweep += 1
                expec_log.append(self.obj_val_sum * scaling)
                
                if not refval is None:
                    if np.isclose(self.best_fval, refval):
                        final_epoch = _
                        final_step = j
                        isbreak = True
                        break

                val0 = expval

                theta_1 = np.copy(theta)
                theta_1[k] += np.pi/2
                val1 = self.calc_expectation(theta_1, objective)

                theta_2 = np.copy(theta)
                theta_2[k] -= np.pi/2
                val2 = self.calc_expectation(theta_2, objective)
                
                theta[k] += self.NFT_update(val0, val1, val2)

            expval = self.calc_expectation(theta, objective)
            

            if intermediate_result_display:
                print(f'final: \t best val = {self.best_fval:.3f}')
        
        return {
            'theta': theta, 
            'expec_log': expec_log,
            'x':self.best_x
        }
