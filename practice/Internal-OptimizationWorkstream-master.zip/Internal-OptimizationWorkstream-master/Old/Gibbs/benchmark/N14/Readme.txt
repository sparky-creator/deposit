seq: 1149_c
rep: 2
alpha = 1.0
nshots = 2^8