import numpy as np


class Quantum_Optimizer():

    def __init__(self) -> None:
        pass


    def set_optimizer(self, num_binary_var, ansatz, sampler):
        self.N = num_binary_var
        self.ansatz = ansatz
        self.sampler = sampler


    def calc_expectation(self, theta, objective:callable):
        """
        Runs the parameterized circuit and returns cVAR value
        """
        
        qc = self.ansatz.bind_parameters(theta)
        qc.measure_all()
        job = self.sampler.run(qc)
        result = job.result()
        quasi_dist = result.quasi_dists[0]
        prob_dict = quasi_dist.binary_probabilities()
        bin_list = list(prob_dict.keys())
        
        nshots = self.sampler.options.shots
        
        counts = {}
        for key, val in prob_dict.items():
            counts[key] = int(round(val * nshots)) 

        obj_val_list = []
        self.entrpy_val_sum = 0.0
        self.obj_val_sum = 0.0
        for bins in bin_list:
            x = np.array(list(bins)).astype(int)
            x = np.flip(x)
            obj_val = objective(x) 
            entrpy_val = (1/self.beta * counts[bins]/nshots * np.log2(counts[bins]/nshots))
            self.obj_val_sum+=(obj_val * counts[bins]/nshots)
            self.entrpy_val_sum+=entrpy_val
            obj_val_list.append(obj_val+entrpy_val)

            if obj_val < self.best_fval:
                self.best_fval = obj_val
                self.best_x = x
        
        #print(obj_val_sum, entrpy_val_sum)
                
        len_list = len(obj_val_list)
        ak = np.ceil(len_list * self.alpha)
        sorted_obj = np.sort(obj_val_list)
        
        cvar = np.sum(sorted_obj[0:int(ak)]) 

        return cvar/ak 
    

    def NFT_update(self, val0, val1, val2, eps=1e-32):
        """
        Parameter update based on the NFT scheme
        """
        z0, z1, z3 = val0, val1, val2
        z2 = z1 + z3 - z0
        dr = eps * (z0 == z2)
        r = (z1 - z3) / ((z0 - z2) + dr)
        dw = np.arctan(float(r))
        dw += np.pi/2 + np.pi/2 * np.sign((z0 - z2) + dr)
        return dw


    def run(self, objective:callable, qc_params_init, scaling, max_epoch=10, random_update=True, 
            intermediate_result_display=False, refval=None, alpha=1.0, beta=0.1):
        
        """
        Main routine that runs for a fixed number of epochs
        
        """
        
        n_params = len(self.ansatz.parameters)
        theta = qc_params_init

        fval_log = []
        final_epoch = 0
        final_step = 0

        self.best_fval = 1e100
        self.best_x = None
        self.entrpy_val_sum = 0.0
        self.obj_val_sum = 0.0
        
        self.alpha = alpha #cVAR param
        self.beta = beta
        
        self.scaling = scaling

        expval = self.calc_expectation(theta, objective)
        
        isbreak = False
        for _ in range(max_epoch):
            if isbreak: break

            if random_update==True:
                idx_set = np.random.permutation(n_params).astype(int)
            else:
                idx_set = np.arange(n_params).astype(int)

            for j, k in enumerate(idx_set):
                if j==0: pass
                else:
                    expval = self.calc_expectation(theta, objective)
                
                if intermediate_result_display:
                    print(f'epoch = {_} \t step = {j} \t best val = {self.best_fval * self.scaling:.3f} \t expectation = {expval:.3f}')

                if not refval is None:
                    if np.isclose(self.best_fval, refval):
                        final_epoch = _
                        final_step = j
                        isbreak = True
                        break

                val0 = expval
                fval_log.append(self.best_fval)

                theta_1 = np.copy(theta)
                theta_1[k] += np.pi/2
                val1 = self.calc_expectation(theta_1, objective)

                theta_2 = np.copy(theta)
                theta_2[k] -= np.pi/2
                val2 = self.calc_expectation(theta_2, objective)
                
                theta[k] += self.NFT_update(val0, val1, val2)
                
                fval_log.append((self.best_fval, expval, 
                             self.entrpy_val_sum, self.obj_val_sum))
            expval = self.calc_expectation(theta, objective)
        
            if intermediate_result_display:
                print(f'final: \t best val = {self.best_fval * self.scaling:.3f}')
        
        return {
            'theta': theta, 
            'fval_log': fval_log,
            'final_epoch': final_epoch,
            'final_step': final_step,
        }
