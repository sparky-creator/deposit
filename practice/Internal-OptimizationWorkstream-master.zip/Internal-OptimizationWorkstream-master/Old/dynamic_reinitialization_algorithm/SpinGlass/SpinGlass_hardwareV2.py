#!/usr/bin/env python
# coding: utf-8
# nohup python SpinGlass_hardwareV2.py --config config_sampleV2.yaml > out_test.txt &

# # Spin Glass - SamplerV2
# This code can address up to 63-qubit instance on simulator.

import numpy as np
import pandas as pd
from hydra import initialize, compose
import dill
import os
import logging
import time
import matplotlib.pyplot as plt
plt.style.use('default')

import qiskit
from qiskit_ibm_runtime import QiskitRuntimeService, Session
from qiskit_aer import AerProvider

from os.path import dirname, abspath
import sys
parent_dir = dirname(dirname(abspath(' ')))
if parent_dir not in sys.path:
    sys.path.append(parent_dir)
from src.bitflip_strategy.Local_Search_PUBO import local_search, comp_objective
from src.optimizer.Quantum_Optimizer_FGSR_b_hardwareV2 import QuantumOptimizer
from src.optimizer.utils_logger import make_logger, initialize_data
from src.optimizer.hardware_utils import create_ansatz, get_initial_layout, dictconfig_to_dict
from Cplex_HuboSolver import CPLEX_HUBOsolver

import warnings
warnings.simplefilter('ignore')

import argparse
parser = argparse.ArgumentParser(description='')
parser.add_argument('--config', help='config file', type=str,default="config_sample.yaml")
args = parser.parse_args()


# Load config file
with initialize(version_base=None, config_path="conf"):
    cfg = compose(config_name=args.config)


# Set backend
env = cfg.backend.env
qiskit_version = int(qiskit.__version__.split(".")[0])

if qiskit_version < 1:
    from qiskit_ibm_runtime import Sampler
    from qiskit.primitives import BackendSampler
else:
    from qiskit_ibm_runtime import (
        SamplerV2 as Sampler,
        SamplerOptions
    )
    from qiskit.primitives import BackendSamplerV2 as BackendSampler

if cfg.backend.env == "hardware" or cfg.layout.use_real_backend:
    service = QiskitRuntimeService(**cfg.QiskitRuntimeService)

if cfg.layout.use_real_backend:
    layout_backend = service.get_backend(cfg.layout.name)
else:
    layout_backend = None

if cfg.backend.env == "hardware":
    backend = service.get_backend(cfg.backend.name)
    layout_backend = backend
else:
    backend = AerProvider().get_backend(cfg.backend.name)
    service = None


# Initialize data and logger
output_dir, idx_set, theta, x_ini, fval, indval, df_job_id, df_result = initialize_data(cfg)
logger = make_logger(cfg, output_dir, backend, env)


idx_set


# Run optimization
logger.info("Backend Info:")
logger.info(f"\tbackend = {backend}")
logger.info(f"\tlayout_backend = {layout_backend}")
instance_list = cfg.instance.list
logger.info("Problem Info:")
logger.info(f"\tinstance_list = {instance_list}")
shots = cfg.sampler_options.default_shots
sampler_options = dictconfig_to_dict(cfg.sampler_options)

result_data = []
for instance in instance_list:
    # Load instance data
    with open(f'{cfg.instance.dir}/{instance}_hubo.pickle', mode='br') as fi:
        data = dill.load(fi)

    # Convert data to pubo format
    pubo_terms = {}
    offset = 0
    qubits_set = set()
    ord = -1
    for key, value in data.items():
        if key == -1:
            offset = value
            continue
        pubo_terms[key] = value
        ord = max(ord, len(key))
        for i in key:
            qubits_set.add(i)
    num_qubits = len(qubits_set)
    obj_data = [num_qubits, pubo_terms]
    cplex_result = CPLEX_HUBOsolver().solve(obj_data)
    refval = cplex_result.fval + offset

    pubo_data = []
    for key in data.keys():
        if key == -1:
            pubo_offset = data[key]
        else:
            l = list(key)
            i = ord - len(l)
            if i > 0:
                for _ in range(i):
                    l.append(l[-1])
            l.append(data[key])
            pubo_data.append(l)
    pubo_data = np.asarray(pubo_data, dtype=float)

    # Define objective
    objective = lambda x: comp_objective(x, ord, pubo_data, pubo_offset)
    def search(x):
        x = local_search(x, ord, pubo_data, pubo_offset, cfg.optimizer.n_flips)
        return np.asarray(x, dtype=int)

    logger.info("-"*130)
    logger.info(f"instance = {instance} \t num_qubits = {num_qubits} \t refval = {refval}")
    logger.info("-"*130)

    for trial in cfg.instance.trial_list:
        np.random.seed(trial)
        if output_dir is not None:
            output_dir_pb_trial = f"{output_dir}/{instance}_trial{trial}"
            if os.path.exists(output_dir_pb_trial) == False:
                os.mkdir(output_dir_pb_trial)
            with open(f"{output_dir_pb_trial}/pubo_data.pickle", 'wb') as f:
                dill.dump(pubo_data, f)
        logger_pb = logging.getLogger(f"SpinGlass Optimization Log: (instance, shots, trial) = {(instance, shots, trial)}")
        logger_pb.setLevel(logging.DEBUG)
        if cfg.options.verbose_optimization:
            st_handler_pb = logging.StreamHandler()
            st_handler_pb.setLevel(logging.DEBUG)
            logger_pb.addHandler(st_handler_pb)
        if output_dir is not None:
                fl_handler_pb = logging.FileHandler(filename=f"{output_dir_pb_trial}/optimization.log", mode="a")
                fl_handler_pb.setLevel(logging.DEBUG)
                logger_pb.addHandler(fl_handler_pb)
        logger_pb.info(f"instance: {instance} \t refval = {refval:.3f} \t shots = {shots} \t trial = {trial}")
        
        # create initial_layout
        chain_nodes = [i for i in range(num_qubits)]
        sep_nodes = []
        sep_nodes_coupling = []
        if layout_backend is not None:
            if cfg.layout.automatic_selection:
                chain_nodes, sep_nodes, sep_nodes_coupling = get_initial_layout(layout_backend, num_qubits, cfg.layout.start_qubit)
                initial_layout = chain_nodes + sep_nodes
            else:
                initial_layout = cfg.initial_layout[cfg.layout.name][:num_qubits]
        else:
            initial_layout = None
        layout_data = {
            "initial_layout": initial_layout,
            "chain_nodes": chain_nodes,
            "sep_nodes": sep_nodes,
            "sep_nodes_coupling": sep_nodes_coupling
        }
        if output_dir is not None:
            with open(f"{output_dir_pb_trial}/layout_data.pickle", 'wb') as f:
                dill.dump(layout_data, f)
        sub_qc = create_ansatz(cfg.optimizer.n_reps, chain_nodes, sep_nodes, sep_nodes_coupling)
        
        with Session(service=service, backend=backend) as session:
            sampler = Sampler(mode=session)
            sampler.options.update(**sampler_options)
            QuantumSolver = QuantumOptimizer()
            QuantumSolver.set_optimizer(num_qubits, sub_qc, sampler, layout_backend, cfg.transpile.optimization_level, initial_layout)
            QuantumSolver.run(
                objective = objective,
                search = search,
                alpha = cfg.optimizer.alpha,
                random_update = cfg.optimizer.random_update,
                max_epoch = cfg.optimizer.max_epoch,
                restart_s = cfg.optimizer.restart_s,
                restart_std = cfg.optimizer.restart_std,
                refval = refval,
                intermediate_result_display = cfg.optimizer.intermediate_result_display,
                early_stop = cfg.optimizer.early_stop,
                x_ini = x_ini,
                output_dir = output_dir_pb_trial,
                logger = logger_pb,
                seed = trial,
                idx_set = idx_set,
                df_job_id = df_job_id,
                df_result = df_result,
                theta = theta,
                mixing_ratio=cfg.optimizer.mixing_ratio,
                fval=fval,
                indval=indval,
                save_counts=cfg.optimizer.save_counts
            )
        step = len(QuantumSolver.result_history)
        objval = QuantumSolver.result_history[-1][3]
        expval = QuantumSolver.result_history[-1][4]
        sprob = QuantumSolver.result_history[-1][5]
        result_data.append([instance, num_qubits, refval, backend.name, shots, trial, step, objval, expval, sprob])
        time.sleep(5)
        logger.info(f"trial = {trial} \t step = {step} \t objval = {objval} \t cvar = {expval} \t s-prob = {sprob}")
        df = pd.DataFrame(data=result_data, columns=["instance", "num_qubits", "refval", "backend", "shots", "trial", "step", "objval", "cvar", "s-prob"])
        df.to_csv(f"{output_dir}/df_result_summary.csv", index=False)