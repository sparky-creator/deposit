import numpy as np
import networkx as nx
from scipy.sparse import coo_matrix
from qiskit_optimization import QuadraticProgram
from qiskit_optimization.algorithms import CplexOptimizer
from qiskit import QuantumRegister
from qiskit.circuit import QuantumCircuit, ParameterVector


def create_random_graph(degree, num_nodes, random_seed, weight_type):
    np.random.seed(random_seed)
    graph = nx.random_regular_graph(d=degree, n=num_nodes, seed=random_seed)

    if weight_type=='one':
        for i,j in graph.edges():
            graph[i][j]['weight'] = 1
    elif weight_type=='binary':
        for i,j in graph.edges():
            graph[i][j]['weight'] = np.random.randint(2)*2-1
    
    return graph


def create_model(graph):
    N = graph.number_of_nodes()

    qubo = {
        (i,i): 0 for i in graph.nodes()
    }

    for i,j in graph.edges():
        w = graph[i][j]['weight']
        if i>j:
            qubo[j,i] = 2 * w
        else:
            qubo[i,j] = 2 * w
        qubo[i,i] -= w
        qubo[j,j] -= w

    Q_data = []
    for key, val in qubo.items():
        Q_data.append([key[0], key[1], val])
    Q_data = np.array(Q_data).astype(float)

    Q = coo_matrix((Q_data[:, 2], (Q_data[:, 0], Q_data[:, 1])), shape=(N, N))

    mdl = QuadraticProgram('QUBO')
    for i in range(N):
        mdl.binary_var(name = f'x_{i}')
    mdl.minimize(quadratic=Q)

    cplex_result = CplexOptimizer().solve(mdl)
    refval = cplex_result.fval

    return Q_data, Q, mdl, cplex_result, refval