import numpy as np
import math
from scipy.sparse import coo_matrix
import networkx as nx
import random
import matplotlib.pyplot as plt
plt.style.use('default')

from qiskit_ibm_runtime import QiskitRuntimeService, Session, Options, Sampler
from qiskit_optimization import QuadraticProgram
from qiskit_optimization.algorithms import CplexOptimizer
from qiskit.primitives import BackendSampler
from qiskit import QuantumRegister
from qiskit.circuit import QuantumCircuit


import json
import pandas as pd
from scipy.sparse import csr_array, csr_matrix
from sklearn import linear_model


from hydra import initialize, compose
from os.path import dirname, abspath
import sys
parent_dir = dirname(dirname(abspath(' ')))
if parent_dir not in sys.path:
    sys.path.append(parent_dir)
import src.encode.encode_permutation as encode_p
import src.encode.encode_combination as encode_c
#from src.bitflip_strategy.local_search_general import *
from src.bitflip_strategy.Local_Search_QUBO import local_search

from src.optimizer.Quantum_Optimizer_FGSR_b_hardware import *
#from src.optimizer.Quantum_Optimizer_FGSR_b import *
from src.optimizer.utils_logger import *

from src.optimizer.hardware_utils import *

from maxcut_utils import *

import warnings
warnings.simplefilter('ignore')

import argparse
parser = argparse.ArgumentParser(description='')
parser.add_argument('--config', help='config file', type=str,default="config_shimada.yaml")
args = parser.parse_args()

# Load config file
with initialize(version_base=None, config_path="conf"):
    cfg = compose(config_name=args.config)

# Set backend
import qiskit
qiskit_version = int(qiskit.__version__.split(".")[0])

env = cfg.params.env
if qiskit_version == 1 and env == "cloud":
    service = QiskitRuntimeService(
        channel=cfg.hardware.channel,
        instance=cfg.hardware.instance,
        token=cfg.hardware.token
    )
    backend = service.get_backend(cfg.hardware.backend)
else:
    from qiskit import Aer
    backend = Aer.get_backend(cfg.simulator.backend)

with open('layout_data_120q.pickle', mode='rb') as f:
    layout_data = dill.load(f)

# Set qubit layout
chain_nodes, sep_nodes, sep_nodes_coupling = layout_data[cfg.hardware.backend]
initial_layout = chain_nodes + sep_nodes


# Initialize data and logger
output_dir, idx_set, theta, x_ini, fval, indval, df_job_id, df_result = initialize_data(cfg)
logger = make_logger(cfg, output_dir, backend, env)

logger.info(f"idx_set: {idx_set}")

# Run optimization

num_nodes = cfg.params.num_nodes
degree = cfg.params.degree
weight_type = cfg.params.weight_type
logger.info("Problem Info:")
logger.info(f"\tnum_nodes = {num_nodes}")
logger.info(f"\tdegree = {degree}")
logger.info(f"\tweight_type = {weight_type}")

shots = cfg.params.shots

result_data = []
for random_seed in cfg.params.random_seed_list:
    #logger.info(f"random_seed = {random_seed}")
    np.random.seed(random_seed)

    graph = create_random_graph(
        degree=degree,
        num_nodes=num_nodes,
        random_seed=random_seed,
        weight_type=weight_type
    )
    Q_data, Q, mdl, cplex_result, refval = create_model(graph)
    num_qubits = graph.number_of_nodes()

    objective = lambda x: x@Q@x
    def search(x):
        x = local_search(x, Q=Q_data, n_flips=cfg.params.n_flips)
        return np.asarray(x, dtype=int)

    #sub_qc = create_circuit(num_qubits, cfg.params.n_reps)
    sub_qc = create_ansatz(cfg.params.n_reps, chain_nodes, sep_nodes, sep_nodes_coupling)

    logger.info("-"*130)
    logger.info(f"random_seed = {random_seed} \t num_qubits = {num_qubits} \t refval = {refval}")
    logger.info("-"*130)

    for trial in cfg.params.trial_list:
        logger.info(f"\ttrial = {trial}")
        np.random.seed(trial)
        if output_dir is not None:
            output_dir_pb_trial = f"{output_dir}/random_seed{random_seed}_trial{trial}"
            if os.path.exists(output_dir_pb_trial) == False:
                os.mkdir(output_dir_pb_trial)
            with open(f"{output_dir_pb_trial}/graph.pickle", 'wb') as f:
                dill.dump(graph, f)
            nx.draw(graph)
            plt.savefig(f"{output_dir_pb_trial}/graph.png")
            plt.savefig(f"{output_dir_pb_trial}/graph.svg", transparent=True, bbox_inches='tight', pad_inches=0)
            plt.close()
        logger_pb = logging.getLogger(f"MaxCut Optimization Log: (random_seed, shots, trial) = {(random_seed, shots, trial)}")
        logger_pb.setLevel(logging.DEBUG)
        if cfg.options.verbose_optimization:
            st_handler_pb = logging.StreamHandler()
            st_handler_pb.setLevel(logging.DEBUG)
            logger_pb.addHandler(st_handler_pb)
        if output_dir is not None:
                fl_handler_pb = logging.FileHandler(filename=f"{output_dir_pb_trial}/optimization.log", mode="a")
                fl_handler_pb.setLevel(logging.DEBUG)
                logger_pb.addHandler(fl_handler_pb)
        logger_pb.info(f"random_seed: {random_seed} \t refval = {refval:.3f} \t shots = {shots} \t trial = {trial}")

        if env == "cloud":
            with Session(service=service, backend=backend) as session:
                #initial_layout = list(cfg.initial_layout[cfg.hardware.backend][:num_qubits])
                options = Options()
                #options.optimization_level = cfg.runtime_options.optimization_level
                options.resilience_level = cfg.runtime_options.resilience_level
                options.execution.shots = shots
                options.transpilation.skip_transpilation = True
                if cfg.hardware.backend not in ["simulator_stabilizer", "simulator_mps", "simulator_extended_stabilizer", "ibmq_qasm_simulator", "simulator_statevector"]:
                    options.transpilation.initial_layout = initial_layout
                sampler = Sampler(session=session, options=options)
                QuantumSolver = QuantumOptimizer()
                QuantumSolver.set_optimizer(num_qubits, sub_qc, sampler, env, backend, cfg.runtime_options.optimization_level, initial_layout)
                QuantumSolver.run(
                    objective = objective,
                    search = search,
                    alpha = cfg.params.alpha,
                    random_update = cfg.params.random_update,
                    max_epoch = cfg.params.max_epoch,
                    restart_s = cfg.params.restart_s,
                    restart_std = cfg.params.restart_std,
                    refval = refval,
                    intermediate_result_display = cfg.params.intermediate_result_display,
                    early_stop = cfg.params.early_stop,
                    x_ini = x_ini,
                    output_dir = output_dir_pb_trial,
                    logger = logger_pb,
                    seed = trial,
                    idx_set = idx_set,
                    df_job_id = df_job_id,
                    df_result = df_result,
                    theta = theta,
                    mixing_ratio=cfg.params.mixing_ratio,
                    fval=fval,
                    indval=indval,
                    save_quasi_dist=cfg.params.save_quasi_dist
                )
        else:
            sampler = BackendSampler(backend=backend)
            sampler.set_options(shots=shots, seed_simulator=trial)
            #sampler.set_options(shots=shots)
            QuantumSolver = QuantumOptimizer()
            QuantumSolver.set_optimizer(num_qubits, sub_qc, sampler, env, backend)
            QuantumSolver.run(
                    objective = objective,
                    search = search,
                    alpha = cfg.params.alpha,
                    random_update = cfg.params.random_update,
                    max_epoch = cfg.params.max_epoch,
                    restart_s = cfg.params.restart_s,
                    restart_std = cfg.params.restart_std,
                    refval = refval,
                    intermediate_result_display = cfg.params.intermediate_result_display,
                    x_ini = x_ini,
                    early_stop = cfg.params.early_stop,
                    output_dir = output_dir_pb_trial,
                    logger = logger_pb,
                    seed = trial,
                    idx_set = idx_set,
                    df_job_id = df_job_id,
                    df_result = df_result,
                    theta = theta,
                    mixing_ratio=cfg.params.mixing_ratio,
                    fval=fval,
                    indval=indval,
                    save_quasi_dist=cfg.params.save_quasi_dist
                )
        step = len(QuantumSolver.result_history)
        objval = QuantumSolver.result_history[-1][3]
        expval = QuantumSolver.result_history[-1][4]
        sprob = QuantumSolver.result_history[-1][5]
        result_data.append([random_seed, num_qubits, refval, backend.name, shots, trial, step, objval, expval, sprob])
        logger.info(f"\tresult: trial = {trial} \t step = {step} \t objval = {objval} \t cvar = {expval} \t s-prob = {sprob}")
        df = pd.DataFrame(data=result_data, columns=["random_seed", "num_qubits", "refval", "backend", "shots", "trial", "step", "objval", "cvar", "s-prob"])
        df.to_csv(f"{output_dir}/df_result_summary.csv", index=False)