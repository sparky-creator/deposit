import numpy as np
from scipy.sparse import csr_array
from scipy.special import comb


class create_encode():

    def __init__(self) -> None:
        pass


    def set_encode(self, n):
        self.n = n

        self.fact_data = np.ones(self.n, dtype=int)
        for k in range(1, self.n):
            self.fact_data[-k-1] = k * self.fact_data[-k]

        self.n_perm = self.n * self.fact_data[0]


    def convert_bitstring_to_int(self, bitstring):
        y = [str(i) for i in bitstring]
        y = ''.join(y)
        integer = int(y, 2)
        return integer


    def convert_int_to_perm(self, integer):
        code = [0] * self.n
        elements = list(range(1, self.n+1))
            
        for i in range(self.n):
            divisor = self.fact_data[i]
            quotient = integer // divisor
            code[i] = elements.pop(quotient)
            integer = integer % divisor

        row = np.arange(self.n)
        col = np.asanyarray(code) - 1
        data = np.ones(self.n, dtype=int)
        p = csr_array((data, (row, col)), shape=(self.n, self.n))
            
        return p

    
    def decode(self, x):
        integer = self.convert_bitstring_to_int(x) % self.n_perm
        P = self.convert_int_to_perm(integer)
        return P.toarray().flatten()