import numpy as np

class create_encode():
    def __init__(self) -> None:
        pass


    def extract_index_set(self, A):
        n = A.shape[1]

        self.index_lists = []
        list_nonzeros_0 = list(range(n))
        list_nonzeros = list_nonzeros_0.copy()

        for _ in range(n):
            list_ones = []
            for idx in list_nonzeros_0:
                if not idx in list_nonzeros: continue

                ltmp = [k for k in list_nonzeros if A[idx,k]==1]
                if set(ltmp) <= set(list_nonzeros):
                    list_nonzeros = ltmp
                    list_ones.append(idx)
            
            if len(list_ones) == 0:
                break

            self.index_lists.append(list_ones)

            list_nonzeros_0 = [k for k in list_nonzeros_0 if not k in list_ones]
            list_nonzeros = list_nonzeros_0.copy()


    def set_encode(self, mdl):
        self.num_bins = mdl.get_num_vars()

        # convert constraints into numpy array
        A = []
        for j in range(mdl.get_num_linear_constraints()):
            l_const_info = mdl.get_linear_constraint(j)
            a = l_const_info.linear.to_array().astype(int)
            A.append(a)
        A = np.asarray(A, dtype=int)

        # convert constraints into the equivalent reduced constraints
        self.As = np.zeros((A.shape[1], self.num_bins), dtype='int')
        count = 0
        for idx in range(A.shape[1]-1):
            y = A[:, idx]
            y = np.argwhere(y==1).flatten()

            s = 0
            for i in range(len(y)):
                if y[i] < count: continue
                self.As[idx, idx:] += A[y[i], idx:]
                s += 1
            count += s
        self.As[-1,-1] = 1

        self.extract_index_set(self.As)
        
        self.n_comb = 1
        for indexes in self.index_lists:
            self.n_comb *= len(indexes) + 1


    def convert_bitstring_to_int(self, bitstring):
        y = [str(i) for i in bitstring]
        y = ''.join(y)
        integer = int(y, 2)
        return integer


    def convert_int_to_x(self, integer):
        l_ones = []
        for indexes in self.index_lists:
            i = len(indexes) + 1
            k = int(integer % i)
            if k < i-1:
                l_ones.append(indexes[k])
            integer = integer // i
        
        x = np.zeros(self.num_bins, dtype=int)
        x[l_ones] = 1

        return x

    
    def decode(self, bitstr):
        integer = self.convert_bitstring_to_int(bitstr) % self.n_comb
        x = self.convert_int_to_x(integer)
        return x