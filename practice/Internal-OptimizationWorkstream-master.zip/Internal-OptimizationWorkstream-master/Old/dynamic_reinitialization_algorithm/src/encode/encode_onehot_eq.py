import numpy as np 
from scipy.linalg import qr
from itertools import combinations
import math


class create_encode():

    def __init__(self) -> None:
        pass


    def convert_bitstring_to_int(self, bitstring):
        y = [str(i) for i in bitstring]
        y = ''.join(y)
        integer = int(y, 2)
        return integer

    
    def set_encode(self, c_obj, A_const):
        n_const, self.N = A_const.shape

        best_conb = None
        best_num = 0
        for j in range(n_const):
            for p in combinations([i for i in range(n_const)], j+1):
                v = np.zeros(self.N, dtype=int)
                for idx in p:
                    v += A_const[idx]
                
                if np.any(v > 1): continue
                
                num_ones = np.sum(v)
                if num_ones > best_num:
                    best_num = num_ones
                    best_conb = p

        P_const = np.zeros((len(best_conb), self.N), dtype=int)
        for k, idx in enumerate(best_conb):
            P_const[k] = A_const[idx]
        
        self.P_matrix = np.zeros((self.N, self.N), dtype=int)
        self.A_const_res = np.zeros((n_const-len(best_conb), self.N), dtype=int)
        count = 0
        idx_res = 0
        for j in range(n_const):
            if j in best_conb:
                for idx in np.argwhere(A_const[j]==1).flatten():
                    self.P_matrix[count, idx] = 1
                    count += 1
            else:
                self.A_const_res[idx_res] = A_const[j]
                idx_res += 1

        v = np.sum(P_const, axis=0)
        for idx in np.argwhere(v==0).flatten():
            self.P_matrix[count, idx] = 1
            count += 1
        self.A_const_p = P_const @ self.P_matrix.T
        self.A_const_res = self.A_const_res @ self.P_matrix.T

        self.c_obj_p = c_obj @ self.P_matrix.T

        self.n_comb = 1
        self.n_col = 0
        for k in range(self.A_const_p.shape[0]):
            n_ones = np.sum(self.A_const_p[k])
            self.n_comb *= n_ones
            self.n_col += n_ones

        self.R_const_p = self.A_const_p[:, :self.n_col]
        self.R_const_res = self.A_const_res[:, :self.n_col]
        self.b_const_res = np.ones(self.R_const_res.shape[0], dtype=int)

        self.A_sub = np.copy(self.A_const_res[:, self.n_col:])

        if self.n_col < self.N:
            G = self.A_sub.T @ self.A_sub
            self.Q, R = qr(G)

            self.idx_add = np.argwhere(np.isclose(np.diag(R), 0)).flatten()
            
            R_add = np.zeros((len(self.idx_add), R.shape[0]))
            for j,k in enumerate(self.idx_add):
                R_add[j,k] = 1
            self.Y = np.vstack((R, R_add))
            self.H = self.Y.T @ self.Y

            self.n_add = len(self.idx_add)
            for _ in range(self.n_add):
                self.n_comb *= 2
            self.n_qubits = math.ceil(np.log2(self.n_comb))

            self.isextend = True

        else:
            self.n_add = 0
            self.n_qubits = math.ceil(np.log2(self.n_comb))
            self.idx_add = []
            self.Q = []
            self.H = []
            self.Y = []

            self.isextend = False

        m = self.A_const_p.shape[0] + self.n_add
        self.r_dig = []
        for k in range(m):
            if k < self.n_add:
                self.r_dig.append(2)
            else:
                self.r_dig.append(np.sum(self.A_const_p[m-1-k]))


    def convert_int_to_bin(self, idx):
        s = idx
        result = []
        for i in self.r_dig:
            result.append(s % i)
            s = s // i
        result.reverse()

        v = np.zeros(self.n_col, dtype=int)
        offset = 0
        for i in range(self.A_const_p.shape[0]):
            k = result[i]
            j = offset + k
            v[j] = 1
            offset += self.r_dig[-1-i]
        
        if self.isextend:
            b_dash = self.b_const_res - self.R_const_res @ v
            b_dash = np.linalg.solve(self.Q, self.A_sub.T@b_dash)
            for j,k in enumerate(self.idx_add):
                i = result[self.A_const_p.shape[0] + j]
                b_dash = np.append(b_dash, i)
            
            v_res = np.linalg.solve(self.H, self.Y.T@b_dash)

            isbinary = True
            for i in range(len(v_res)):
                val = v_res[i]
                
                iszero = np.isclose(val, 0)
                isone = np.isclose(val, 1)
                if iszero:
                    val = 0
                elif isone:
                    val = 1
                else:
                    isbinary = False
                    break

                v_res[i] = val
            
            if isbinary == True:
                v = np.hstack((v, v_res.astype(int)))
                x = self.P_matrix.T @ v
            else:
                x = None

        else:
            x = self.P_matrix.T @ v
        
        return x

    
    def decode(self, x):
        integer = self.convert_bitstring_to_int(x) % self.n_comb
        v = self.convert_int_to_bin(integer)
        if v is None:
            v = np.ones(self.N, dtype=int)
        return v
