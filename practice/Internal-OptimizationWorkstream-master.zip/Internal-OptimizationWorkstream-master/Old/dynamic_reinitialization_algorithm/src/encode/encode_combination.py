import numpy as np
from scipy.special import comb
from copy import deepcopy


class create_encode():

    def __init__(self) -> None:
        pass


    def set_encode(self, n, k):
        self.n = n
        self.k = k
        self.n_comb = int(comb(n, k, exact=True))
        self.n_comb_0 = self.n_comb * k / n


    def convert_bitstring_to_int(self, bitstring):
        y = [str(i) for i in bitstring]
        y = ''.join(y)
        integer = int(y, 2)
        return integer
    
    
    def convert_int_to_comb(self, integer):
        integer = self.n_comb - 1 - integer
        n = deepcopy(self.n)
        k = deepcopy(self.k)
        comb_val = deepcopy(self.n_comb_0)
        comb_val = round(comb_val)

        combination = []
        while n > 0 and k > 0:
            if integer < comb_val:
                combination.insert(0, n-1)
                comb_val *= (k-1) / (n-k+1)
                comb_val = round(comb_val)
                k -= 1
            else:
                integer -= comb_val
            
            if n > 1:
                comb_val *= (n-k) / (n-1)
                comb_val = round(comb_val)
            else:
                comb_val *= (n-k)
                comb_val = round(comb_val)
            n -= 1
        
        return combination
    
    
    def decode(self, x):
        integer = self.convert_bitstring_to_int(x) % self.n_comb
        idx = self.convert_int_to_comb(integer)
        y = np.zeros(self.n, dtype=int)
        y[idx] = 1
        return y