import numpy as np 
from itertools import product, combinations


def local_search_general(x, func:callable, k=1, maxiter=10, maxepoch=1):
    N = len(x)
    all_combinations = list(combinations(range(N), k))
    is_stop = False
    count = 0
    
    for _ in range(maxepoch):
        if is_stop:
            break

        for comb in np.random.permutation(all_combinations): 
            val_base = func(x)

            z = np.copy(x)
            for idx in comb:
                z[idx] = 1 - z[idx]
            val_flip = func(z)

            if not val_base < val_flip:
                x = z
            
            count += 1
            if count == maxiter:
                is_stop = True
                break

    return x