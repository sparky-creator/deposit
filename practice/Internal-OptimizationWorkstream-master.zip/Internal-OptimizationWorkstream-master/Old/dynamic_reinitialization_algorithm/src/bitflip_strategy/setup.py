#python setup.py build_ext --inplace

from distutils.core import setup
from distutils.extension import Extension
from Cython.Distutils import build_ext
from numpy import get_include

file_name = 'Local_Search_QUBO'

ext_module = Extension(
    name=file_name,
    sources=[file_name + '.pyx'],
    extra_compile_args=['-fopenmp'],
    include_dirs=['.', get_include()]
)

setup(
    name = file_name,
    cmdclass = {'build_ext': build_ext},
    ext_modules = [ext_module],
)