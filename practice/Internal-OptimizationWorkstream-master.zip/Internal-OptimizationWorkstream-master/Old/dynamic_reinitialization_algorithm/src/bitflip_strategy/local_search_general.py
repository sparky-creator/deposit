import numpy as np 


def local_search(x, func:callable, maxiter=10, maxepoch=1):
    N = len(x)
    is_stop = False
    count = 0
    
    for _ in range(maxepoch):
        if is_stop:
            break

        for idx in np.random.permutation(N): 
            val_base = func(x)

            z = np.copy(x)
            z[idx] = (z[idx] + 1) %2
            val_flip = func(z)

            if not val_base < val_flip:
                x = z
            
            count += 1
            if count == maxiter:
                is_stop = True
                break

    return x