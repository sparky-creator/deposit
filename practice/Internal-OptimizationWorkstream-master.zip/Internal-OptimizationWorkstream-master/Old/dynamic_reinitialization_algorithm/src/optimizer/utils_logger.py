import dill
import os
import datetime
from dateutil import tz
from omegaconf import OmegaConf
import pandas as pd
import dill
import logging


def make_output_folder(cfg):
    output_dir = cfg.options.output_dir
    if os.path.exists(output_dir) == False:
        os.mkdir(output_dir)
    TZ = tz.gettz(cfg.options.timezone)
    date = datetime.datetime.now(TZ).strftime('%Y%m%d-%H%M%S')
    output_dir = f"{output_dir}/{date}"
    if os.path.exists(output_dir) == False:
        os.mkdir(output_dir)
    print("output_dir:", output_dir)
    with open(f"{output_dir}/config.yaml", "w") as f:
        OmegaConf.save(cfg, f.name)

    return output_dir


def make_logger(cfg, output_dir, backend, env):
    logger = logging.getLogger("Task Execution Optimization Log")
    logger.setLevel(logging.DEBUG)
    if cfg.options.verbose:
        st_handler = logging.StreamHandler()
        st_handler.setLevel(logging.DEBUG)
        logger.addHandler(st_handler)
    if output_dir is not None:
        fl_handler = logging.FileHandler(filename=f"{output_dir}/summary.log", mode="a")
        fl_handler.setLevel(logging.DEBUG)
        logger.addHandler(fl_handler)
    logger.info("Parameters:")
    for key1 in cfg.keys():
        if "initial_layout" in key1: continue
        logger.info(f"\t{key1}:")
        for key2, value in cfg[key1].items():
            logger.info(f"\t\t{key2} = {value}")
    """
    for key, value in cfg.params.items():
        logger.info(f"\t{key} = {value}")
    #logger.info(f"\tnum_parameters = {sub_qc.num_parameters}")
    logger.info(f"Backend = {backend}")
    if env == "cloud":
        logger.info("\tHardware")
        for key, value in cfg.hardware.items():
            logger.info(f"\t\t{key} = {value}")
    """
    return logger

def initialize_data(cfg):
    if cfg.options.restart:
        output_dir = f"{cfg.options.output_dir}/{cfg.options.date}"
        with open(f"{output_dir}/idx_set.pickle", 'rb') as f:
            idx_set = dill.load(f)
        with open(f"{output_dir}/theta_history.pickle", 'rb') as f:
            theta_history = dill.load(f)
            theta = theta_history[-1][0]
        with open(f"{output_dir}/x.pickle", 'rb') as f:
            x_ini = dill.load(f)
        with open(f"{output_dir}/fval.pickle", 'rb') as f:
            fval = dill.load(f)
        with open(f"{output_dir}/indval.pickle", 'rb') as f:
            indval = dill.load(f)
        df_job_id = pd.read_csv(f"{output_dir}/df_job_id.csv")
        df_result = pd.read_csv(f"{output_dir}/df_result.csv")
    else:
        idx_set = []
        theta = None
        x_ini = None
        fval = float('inf')
        indval = None
        df_job_id = None
        df_result = None
        if cfg.options.save_result:
            output_dir = make_output_folder(cfg)
        else:
            output_dir = None

    return output_dir, idx_set, theta, x_ini, fval, indval, df_job_id, df_result