import numpy as np
import math
from qiskit import QuantumRegister
from qiskit.circuit import QuantumCircuit, ParameterVector
from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
import pandas as pd
import dill

class QuantumOptimizer():

    def __init__(self) -> None:
        pass


    def set_optimizer(self, num_qubits, sub_qc, sampler, env, backend=None, optimization_level=0, initial_layout=None):
        # create ansatz for restarting
        self.num_qubits = num_qubits
        q = QuantumRegister(self.num_qubits, name='q')
        self.ansatz = QuantumCircuit(q)
        ## assign initial guess
        qc_params = ParameterVector(name='w', length=self.num_qubits)
        for idx in range(self.num_qubits):
            self.ansatz.ry(qc_params[idx], q[idx])
        self.ansatz.barrier()
        ## assign variational parameters
        self.ansatz.append(sub_qc, q)
        self.n_params = sub_qc.num_parameters

        # set sampler
        self.sampler = sampler
        self.env = env
        self.backend = backend
        if self.env == "hardware":
            self.nshots = self.sampler.options.execution["shots"]
        else:
            self.nshots = self.sampler.options.shots
        self.optimization_level = optimization_level
        self.initial_layout = initial_layout


    def all_optimization_circs(self, theta_list, x):
        circs = []
        for theta in theta_list:
            w = x * self.restart_s * np.pi
            phi = np.hstack((w, theta))
            circ = self.ansatz.assign_parameters(phi)
            circ.measure_all()
            circs.append(circ)
        if self.env == "hardware":
            pm = generate_preset_pass_manager(backend=self.backend, optimization_level=self.optimization_level, initial_layout=self.initial_layout)
            circs = pm.run(circs)
        return circs


    def run_sampler(self, circs):
        job = self.sampler.run(circs)
        # Save job id
        self.job_history.append(job.job_id())
        df_job_id = pd.DataFrame(data=self.job_history, columns=["job_id"])
        if self.output_dir is not None:
            if self.df_job_id is not None:
                df_job_id = pd.concat([self.df_job_id, df_job_id])
            df_job_id.to_csv(f"{self.output_dir}/df_job_id.csv", index=False)
        result = job.result()
        return result


    def calc_expectation(self, result):
        expval_list = []
        self.sprob = 0
        if self.save_quasi_dist:
            self.quasi_dist_list.append(result.quasi_dists)
        for i, quasi_dist in enumerate(result.quasi_dists):
            sprob = 0
            fval_list = []
            for bin, prob in quasi_dist.binary_probabilities().items():
                x = np.array(list(bin)).astype(int)
                x = np.flip(x)

                fvals = self.objective(x)
                if np.isscalar(fvals):
                    fval = fvals
                    indval = None
                else:
                    fval = fvals['objective']
                    indval = fvals['indicator']

                if not self.refval is None:
                    #if np.isclose(fval, self.refval) and i == 0:
                    if np.isclose(fval, self.refval):
                        sprob += prob
                
                if self.op_trans is None:
                    tfval = fval
                else:
                    tfval = self.op_trans(fval)
                
                count = round(prob * self.nshots)
                fval_list += [tfval]*count
                
                if not self.search is None:
                    if not self.refval is None and not np.isclose(self.fval, self.refval):
                        x = self.search(x)
                        fvals = self.objective(x)
                        if np.isscalar(fvals):
                            fval = fvals
                            indval = None
                        else:
                            fval = fvals['objective']
                            indval = fvals['indicator']
                
                if fval < self.fval:
                    self.fval = fval
                    self.x = x
                    self.indval = indval
                    
                    self.restart = True
            self.sprob = max(self.sprob, sprob)

            len_list = len(fval_list)
            ak = round(len_list * self.alpha)
            fval_list.sort()
            cvar = np.mean(fval_list[:ak])
            expval_list.append(cvar)
        return expval_list
    

    def GS_update(self, val0, val1, val2, eps=1e-32):
        z0, z1, z3 = val0, val1, val2
        z2 = z1 + z3 - z0
        dr = eps * (z0 == z2)
        r = (z1 - z3) / ((z0 - z2) + dr)
        dw = np.arctan(float(r))
        dw += np.pi/2 + np.pi/2 * np.sign((z0 - z2) + dr)
        return dw


    def run(
            self,
            objective:callable,
            search:callable = None,
            op_trans:callable = None,
            alpha = 1.0,
            max_epoch = 1,
            x_ini = None,
            restart_s = 0.8,
            restart_std = 0.1,
            mixing_ratio = 0.0,
            random_update = True,
            refval = None,
            early_stop = False,
            intermediate_result_display = False,
            output_dir = None,
            logger = None,
            seed = 42,
            idx_set = [],
            df_job_id = None,
            df_result = None,
            theta = None,
            g = 2.0/3.0,
            fval = float('inf'),
            indval = None,
            save_quasi_dist=True
        ):

        self.objective = objective
        self.search = search
        self.op_trans = op_trans
        self.alpha = alpha
        self.restart_s = restart_s
        self.restart_std = restart_std
        self.ratio = mixing_ratio
        self.output_dir = output_dir
        self.logger = logger
        self.seed = seed
        self.df_job_id = df_job_id
        self.df_result = df_result
        self.save_quasi_dist = save_quasi_dist
        np.random.seed(self.seed)

        if theta is None:
            self.theta = np.zeros(self.n_params)
        else:
            self.theta = theta

        self.log = []
        self.elog = []
        self.plog = []
        self.final_epoch = 0
        self.final_step = 0

        self.theta_history = [np.copy(self.theta)]
        self.result_history = []
        self.job_history = []
        self.idx_set = idx_set
        self.g = g
        self.quasi_dist_list = []

        if x_ini is None:
            self.x = np.full(fill_value=0.5/self.restart_s, shape=self.num_qubits)
        else:
            self.x = x_ini
        
        self.fval = fval
        self.indval = indval
        self.refval = refval

        x_best = self.x

        if self.logger is not None:
            self.logger.info("\tOptimization Start")
        
        for epoch in range(max_epoch):
            is_stop = False
            initialize_idx_set = False
            step = 0
            while not is_stop:
                self.restart = False

                if len(self.idx_set) == 0 or initialize_idx_set:
                    if random_update:
                        idx_set = np.random.permutation(self.n_params).astype(int)
                    else:
                        idx_set = np.arange(self.n_params).astype(int)
                        idx_set = np.flip(idx_set)
                    self.idx_set = list(idx_set)

                for j in range(self.n_params):
                    # select parameter index
                    k = self.idx_set[0]

                    # prepare parameters to compute gradient
                    theta_list = [self.theta]
                    theta_1 = np.copy(self.theta)
                    theta_1[k] += self.g*np.pi
                    theta_list.append(theta_1)
                    theta_2 = np.copy(self.theta)
                    theta_2[k] -= self.g*np.pi
                    theta_list.append(theta_2)

                    # transpile and run circuits with sampler
                    circs = self.all_optimization_circs(theta_list, x_best)
                    result = self.run_sampler(circs)

                    # update parameters
                    expval, val1, val2 = self.calc_expectation(result)
                    self.theta[k] += self.GS_update(expval, val1, val2)
                    self.theta_history.append([np.copy(self.theta)])
                    self.elog.append(expval)
                    self.plog.append(self.sprob)
                    
                    if self.indval is None:
                        objval = self.fval
                    else:
                        objval = self.indval
                    
                    self.result_history.append([epoch, step, j, k, objval, expval, self.sprob])
                    
                    if intermediate_result_display:
                        if self.indval is None:
                            print(f'\tepoch = {epoch} \t step = {step} \t (j, k) = {(j, k)} \t objval = {objval:.3f} \t cvar = {expval:.3f}   \t s-prob = {self.sprob:.3e}')
                        else:
                            ind = list(map(round, objval, [3]*len(objval)))
                            print(f'\tepoch = {epoch} \t step = {step} \t (j, k) = {(j, k)} \t indicator = {ind} \t cvar = {expval:.3f}   \t s-prob = {self.sprob:.3e}')
                    if self.logger is not None:
                        if self.indval is None:
                            self.logger.info(f'\tepoch = {epoch} \t step = {step} \t (j, k) = {(j, k)} \t objval = {objval:.3f} \t cvar = {expval:.3f} \t s-prob = {self.sprob:.3e}')
                        else:
                            ind = list(map(round, objval, [3]*len(objval)))
                            self.logger.info(f'\tepoch = {epoch} \t step = {step} \t (j, k) = {(j, k)} \t indicator = {ind} \t cvar = {expval:.3f} \t s-prob = {self.sprob:.3e}')

                    x_best = self.x
                    step += 1

                    self.idx_set.pop(0)
                    if self.output_dir is not None:
                        self.save_result()

                    if self.restart:
                        self.theta = np.random.normal(loc=0, scale=self.restart_std, size=self.n_params)
                        #self.theta_history.append([np.copy(self.theta)])
                        initialize_idx_set = True
                        if self.output_dir is not None:
                            self.save_result()
                    
                        break
                
                    if early_stop == True:
                        if refval is None: pass
                        elif np.isclose(self.fval, refval):
                            is_stop = True
                            break
                    
                    if len(self.idx_set) == 0:
                        is_stop = True
                        break
    

    def save_result(self):
        with open(f"{self.output_dir}/theta_history.pickle", 'wb') as f:
            dill.dump(self.theta_history, f)
        with open(f"{self.output_dir}/idx_set.pickle", 'wb') as f:
            dill.dump(self.idx_set, f)
        with open(f"{self.output_dir}/logger.pickle", 'wb') as f:
            dill.dump(self.logger, f)
        with open(f"{self.output_dir}/x.pickle", 'wb') as f:
            dill.dump(self.x, f)
        with open(f"{self.output_dir}/fval.pickle", 'wb') as f:
            dill.dump(self.fval, f)
        with open(f"{self.output_dir}/indval.pickle", 'wb') as f:
            dill.dump(self.indval, f)
        with open(f"{self.output_dir}/quasi_dist_list.pickle", 'wb') as f:
            dill.dump(self.quasi_dist_list, f)
        if self.indval is None:
            columns = ["epoch", "step", "j", "k", "objval", "cvar", "s-prob"]
        else:
            columns = ["epoch", "step", "j", "k", "indicator", "cvar", "s-prob"]
        df = pd.DataFrame(data=self.result_history, columns=columns)
        if self.df_result is not None:
            df = pd.concat([self.df_result, df])
        df.to_csv(f"{self.output_dir}/df_result.csv", index=False)