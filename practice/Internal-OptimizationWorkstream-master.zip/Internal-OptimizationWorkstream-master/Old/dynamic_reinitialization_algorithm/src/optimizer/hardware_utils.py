import numpy as np
from qiskit.circuit import QuantumCircuit, ParameterVector
from qiskit import QuantumRegister
from omegaconf import OmegaConf, DictConfig


def get_graph(backend):
    graph = {i:set() for i in range(backend.num_qubits)}
    for i, j in backend.coupling_map:
        graph[i].add(j)
        graph[j].add(i)

    return graph


def get_longest_path(graph, start):
    def dfs(node, visited):
        visited.add(node)
        max_distance = 1
        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                distance = dfs(neighbor, visited)
                max_distance = max(max_distance, distance + 1)
        visited.remove(node)
        return max_distance
    
    visited = set()
    return dfs(start, visited)


def get_noise_info(backend):
    # get backend properties
    properties = backend.properties()

    # get native two-qubit gate type
    gate_type = "" 
    for gate in properties.gates:
        if len(gate.qubits) == 2:
            gate_type = gate.gate

    # get readout error of each qubit
    readout_errors = [properties.qubit_property(i, 'readout_error')[0] for i in range(backend.configuration().n_qubits)]

    # get two-qubit error of each qubit
    cnot_errors = {}
    cnot_errors_sum = {i: [] for i in range(backend.configuration().n_qubits)}
    for qubit in range(backend.configuration().n_qubits):
        for gate in properties.gates:
            if gate_type in gate.name and gate.qubits[0] == qubit:
                q1, q2 = gate.qubits
                gate_error = properties.gate_property(gate_type)[q1, q2]["gate_error"][0]
                cnot_errors[q1, q2] = gate_error
                cnot_errors[q2, q1] = gate_error
                cnot_errors_sum[q1].append(gate_error)
                cnot_errors_sum[q2].append(gate_error)

    cnot_errors_mean = [np.mean(value) for value in cnot_errors_sum.values()]

    # compute total error rate (mean value of readout and two-qubit errors)
    total_errors = np.add(readout_errors, cnot_errors_mean)

    return readout_errors, cnot_errors, total_errors


def get_total_error(path, readout_errors, cnot_errors):
    total_error = sum([readout_errors[n] for n in path])
    for i in range(len(path)-1):
        n1 = path[i]
        n2 = path[i+1]
        total_error += cnot_errors[n1, n2]
    return total_error


def get_longest_path_with_min_error(graph, start, max_distance, readout_errors, cnot_errors):

    def dfs(node, visited, path, max_distance, min_path, min_error, readout_errors, cnot_errors, all_path):
        visited.add(node)
        path.append(node)
        if len(path) == max_distance:
            temp_error = get_total_error(path, readout_errors, cnot_errors)
            key = "-".join([str(i) for i in path])
            all_path[key] = temp_error
            if temp_error < min_error:
                min_error = temp_error
                min_path = path[:]
        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                min_path, min_error, all_path = dfs(neighbor, visited, path, max_distance, min_path, min_error, readout_errors, cnot_errors, all_path)
        visited.remove(node)
        path.pop()
        return min_path, min_error, all_path
    
    visited = set()
    min_path = []
    min_error = 10**10
    all_path = {}
    
    return dfs(start, visited, [], max_distance, min_path, min_error, readout_errors, cnot_errors, all_path)


def get_coupling_map_sep_nodes(graph, chain_nodes, sep_nodes, cnot_errors):
    qubit_map_virtual_to_physical = {i: q for i, q in enumerate(chain_nodes)}
    for i, q in enumerate(sep_nodes):
        qubit_map_virtual_to_physical[i+len(chain_nodes)] = q
    qubit_map_physical_to_virtual = {value: key for key, value in qubit_map_virtual_to_physical.items()}

    coupling_map = []
    for k in sep_nodes:
        min_error = 10**10
        k_neighbor = -1
        for l in graph[k]:
            if cnot_errors[k, l] < min_error:
                min_error = cnot_errors[k, l]
                k_neighbor = l
        k1 = qubit_map_physical_to_virtual[k]
        k2 = qubit_map_physical_to_virtual[k_neighbor]
        coupling_map.append((k1, k2))

    return coupling_map


def get_initial_layout(backend, num_qubits, start):
    graph = get_graph(backend)
    max_distance = min(get_longest_path(graph, start), num_qubits)
    readout_errors, cnot_errors, total_errors = get_noise_info(backend)
    chain_nodes, min_error, all_path = get_longest_path_with_min_error(graph, start, max_distance, readout_errors, cnot_errors)
    if len(chain_nodes) >= num_qubits:
        return chain_nodes, [], []
    else:
        sorted_qubits = np.argsort(total_errors)
        total_errors = total_errors[sorted_qubits]
        sep_nodes = []
        for q in sorted_qubits:
            if q in chain_nodes: continue
            if len(chain_nodes) + len(sep_nodes) < num_qubits:
                sep_nodes.append(q)
        # virtual qubit coupling
        sep_nodes_coupling = get_coupling_map_sep_nodes(graph, chain_nodes, sep_nodes, cnot_errors)

        return chain_nodes, sep_nodes, sep_nodes_coupling


def create_ansatz(reps, chain_nodes, sep_nodes, sep_nodes_coupling):
    num_qubits = len(chain_nodes) + len(sep_nodes)
    qc = QuantumCircuit(num_qubits)
    q = QuantumRegister(num_qubits, name='q')
    qc_params = ParameterVector(name='theta', length=num_qubits*reps)
    for r in range(reps):
        for k in range(0, len(chain_nodes), 2):
            if k+1 >= len(chain_nodes): break
            qc.cz(q[k], q[k+1])

        for k in range(1, len(chain_nodes), 2):
            if k+1 >= len(chain_nodes): break
            qc.cz(q[k], q[k+1])
        
        for k1, k2 in sep_nodes_coupling:
            qc.cz(q[k1], q[k2])
        
        for k in range(num_qubits):
            qc.ry(qc_params[r*num_qubits+k], q[k])
        
        qc.barrier()

    return qc


def dictconfig_to_dict(dict_config: DictConfig) -> dict:
    return OmegaConf.to_container(dict_config, resolve=True)