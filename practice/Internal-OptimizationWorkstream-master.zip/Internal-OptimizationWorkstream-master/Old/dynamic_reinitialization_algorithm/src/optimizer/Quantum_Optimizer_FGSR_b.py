import numpy as np
import math
from qiskit import QuantumRegister
from qiskit.circuit import QuantumCircuit, ParameterVector

class QuantumOptimizer():

    def __init__(self) -> None:
        pass


    def set_optimizer(self, num_qubits, sub_qc, sampler):
        self.num_qubits = num_qubits
        self.sampler = sampler

        # create ansatz for restarting
        q = QuantumRegister(self.num_qubits, name='q')
        self.ansatz = QuantumCircuit(q)

        qc_params = ParameterVector(name='w', length=self.num_qubits)
        for idx in range(self.num_qubits):
            self.ansatz.ry(qc_params[idx], q[idx])

        self.ansatz.barrier()
        self.ansatz.append(sub_qc, q)

        self.n_params = sub_qc.num_parameters
    

    def calc_expectation(self, theta, x):
        w = x * self.restart_s * np.pi
        phi = np.hstack((w, theta))
        qc = self.ansatz.assign_parameters(phi)
        qc.measure_all()

        job = self.sampler.run(qc)
        result = job.result()
        quasi_dist = result.quasi_dists[0]
        prob_dict = quasi_dist.binary_probabilities()

        nshots = self.sampler.options.shots

        fval_list = []
        self.sprob = 0
        for bin, prob in prob_dict.items():
            x = np.array(list(bin)).astype(int)
            x = np.flip(x)

            fvals = self.objective(x)
            if np.isscalar(fvals):
                fval = fvals
                indval = None
            else:
                fval = fvals['objective']
                indval = fvals['indicator']

            if not self.refval is None:
                if np.isclose(fval, self.refval):
                    self.sprob += prob
            
            if self.op_trans is None:
                tfval = fval
            else:
                tfval = self.op_trans(fval)
            
            count = int(prob * nshots) 
            fval_list += [tfval]*count
            
            if not self.search is None:
                if not np.isclose(self.fval, self.refval):
                    x = self.search(x)
                    fvals = self.objective(x)
                    if np.isscalar(fvals):
                        fval = fvals
                        indval = None
                    else:
                        fval = fvals['objective']
                        indval = fvals['indicator']
            
            if fval < self.fval:
                self.fval = fval
                self.x = x
                self.indval = indval
                
                self.restart = True

        len_list = len(fval_list)
        ak = math.ceil(len_list * self.alpha)
        fval_list.sort()
        cvar = np.mean(fval_list[:ak])

        return cvar
    

    def GS_update(self, val0, val1, val2, eps=1e-32):
        z0, z1, z3 = val0, val1, val2
        z2 = z1 + z3 - z0
        dr = eps * (z0 == z2)
        r = (z1 - z3) / ((z0 - z2) + dr)
        dw = np.arctan(float(r))
        dw += np.pi/2 + np.pi/2 * np.sign((z0 - z2) + dr)
        return dw


    def run(self, 
            objective:callable, 
            search:callable = None,
            op_trans:callable = None, 
            alpha = 1.0,
            max_epoch = 1, 
            x_ini = None,
            restart_s = 0.8,
            restart_std = 0.1,
            random_update = True, 
            refval = None,
            early_stop = False,
            intermediate_result_display = False
            ):

        self.objective = objective
        self.search = search
        self.op_trans = op_trans
        self.alpha = alpha
        self.restart_s = restart_s
        self.restart_std = restart_std

        self.theta = np.zeros(self.n_params)

        self.log = []
        self.elog = []
        self.plog = []
        self.final_epoch = 0
        self.final_step = 0

        if x_ini is None:
            self.x = np.full(fill_value=0.5/self.restart_s, shape=self.num_qubits)
        else:
            self.x = x_ini
        
        self.fval = float('inf')
        self.indval = None
        self.refval = refval

        x_best = self.x
        
        for _ in range(max_epoch):
            is_stop = False
            while not is_stop:
                self.restart = False

                if random_update==True:
                    idx_set = np.random.permutation(self.n_params).astype(int)
                else:
                    idx_set = np.arange(self.n_params).astype(int)
                    idx_set = np.flip(idx_set)

                for j, k in enumerate(idx_set):
                    expval = self.calc_expectation(self.theta, x_best)

                    self.elog.append(expval)
                    self.plog.append(self.sprob)
                    
                    if self.indval is None:
                        objval = self.fval
                    else:
                        objval = self.indval
                    
                    if intermediate_result_display:
                        if self.indval is None:
                            print(f'epoch = {_} \t step = {j} \t objval = {objval:.3f} \t cvar = {expval:.3f}   \t s-prob = {self.sprob:.3e}')
                        else:
                            ind = list(map(round, objval, [3]*len(objval)))
                            print(f'epoch = {_} \t step = {j} \t indicator = {ind} \t cvar = {expval:.3f}   \t s-prob = {self.sprob:.3e}')

                    val0 = expval
                    self.log.append(objval)

                    theta_1 = np.copy(self.theta)
                    #g = np.random.uniform(0.5, 1.0)
                    g = 2/3
                    theta_1[k] += g*np.pi
                    val1 = self.calc_expectation(theta_1, x_best)

                    theta_2 = np.copy(self.theta)
                    #g = np.random.uniform(0.5, 1.0)
                    g = 2/3
                    theta_2[k] -= g*np.pi
                    val2 = self.calc_expectation(theta_2, x_best)
                    
                    self.theta[k] += self.GS_update(val0, val1, val2)
                    
                    x_best = self.x

                    if self.restart:
                        self.theta = np.random.normal(loc=0, scale=self.restart_std, size=self.n_params)
                        break
                
                    if early_stop == True:
                        if refval is None: pass
                        elif np.isclose(self.fval, refval):
                            is_stop = True
                            break
                    elif j == len(idx_set)-1:
                        is_stop = True