import numpy as np
from qiskit.circuit.library import TwoLocal


class ClassicalSampler():

    def __init__(self) -> None:
        pass


    def set_optimizer(self, sampler, size):
        self.num_qubits = size
        self.sampler = sampler

        self.ansatz = TwoLocal(
            num_qubits = self.num_qubits,
            rotation_blocks = 'ry', 
            entanglement_blocks = 'cz',
            entanglement = 'pairwise', 
            reps = 0,
            )
        self.n_params = self.ansatz.num_parameters


    def run_qc_sampler(self, theta):
        qc = self.ansatz.bind_parameters(theta)
        qc.measure_all()
        job = self.sampler.run(qc)
        result = job.result()
        
        quasi_dist = result.quasi_dists[0]
        self.prob_dict = quasi_dist.binary_probabilities()
        self.bin_list = list(self.prob_dict.keys())
    
    
    def uniform_sampler(self, intermediate_result_display):
        theta = np.full(self.num_qubits, np.pi/2)
        self.run_qc_sampler(theta)

        for bin in self.bin_list:
            x = np.array(list(bin)).astype(int)
            x = np.flip(x)

            if not self.encode is None:
                x = self.encode(x)

            fvals = self.objective(x)
            if np.isscalar(fvals):
                fval = fvals
                indval = None
            else:
                fval = fvals['objective']
                indval = fvals['indicator']
            
            if not self.search is None:
                x = self.search(x)
                fvals = self.objective(x)
                if np.isscalar(fvals):
                    fval = fvals
                    indval = None
                else:
                    fval = fvals['objective']
                    indval = fvals['indicator']
            
            if fval < self.fval:
                self.fval = fval
                self.x = x
                self.indval = indval
        
        if self.indval is None:
            objval = self.fval
        else:
            objval = self.indval

        if intermediate_result_display == True:
            if self.indval is None:
                print(f'step = {self.step} \t objval = {objval:.3f}')
            else:
                ind = list(map(round, objval, [3]*len(objval)))
                print(f'step = {self.step} \t indicator = {ind}')

        self.log.append(objval)

        if not self.refval is None:
            if np.isclose(self.fval, self.refval):
                self.stp = True
        
        self.step += 1


    def run(
        self, 
        objective:callable, 
        encode:callable = None,
        search:callable = None,
        maxiter = 100, 
        refval = None, 
        intermediate_result_display = False
        ):

        self.objective = objective
        self.encode = encode
        self.search = search
        self.refval = refval
        self.step = 0
        self.x = np.zeros(self.num_qubits, dtype=int)
        self.fval = float('inf')
        self.indval = None
        self.log = []
        self.stp = False

        for _ in range(maxiter):
            self.uniform_sampler(intermediate_result_display)
            if self.stp:
                break