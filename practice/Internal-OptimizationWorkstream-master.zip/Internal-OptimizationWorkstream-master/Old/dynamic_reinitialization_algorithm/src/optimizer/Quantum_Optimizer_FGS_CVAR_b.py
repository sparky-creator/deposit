import numpy as np
import math

class QuantumOptimizer():

    def __init__(self) -> None:
        pass


    def set_optimizer(self, ansatz, sampler):
        self.ansatz = ansatz
        self.num_qubits = ansatz.num_qubits
        self.n_params = ansatz.num_parameters
        self.sampler = sampler


    def calc_expectation(self, theta):
        qc = self.ansatz.bind_parameters(theta)
        qc.measure_all()
        job = self.sampler.run(qc)
        result = job.result()
        quasi_dist = result.quasi_dists[0]
        prob_dict = quasi_dist.binary_probabilities()

        nshots = self.sampler.options.shots

        fval_list = []
        self.sprob = 0
        for bin, prob in prob_dict.items():
            x = np.array(list(bin)).astype(int)
            x = np.flip(x)

            if not self.encode is None:
                x = self.encode(x)

            fvals = self.objective(x)
            if np.isscalar(fvals):
                fval = fvals
                indval = None
            else:
                fval = fvals['objective']
                indval = fvals['indicator']

            if not self.refval is None:
                if np.isclose(fval, self.refval):
                    self.sprob += prob
            
            if self.op_trans is None:
                tfval = fval
            else:
                tfval = self.op_trans(fval)
            
            count = int(prob * nshots) 
            fval_list += [tfval]*count
            
            if not self.search is None:
                x = self.search(x)
                fvals = self.objective(x)
                if np.isscalar(fvals):
                    fval = fvals
                    indval = None
                else:
                    fval = fvals['objective']
                    indval = fvals['indicator']
            
            if fval < self.fval:
                self.fval = fval
                self.x = x
                self.indval = indval

        len_list = len(fval_list)
        ak = math.ceil(len_list * self.alpha)
        fval_list.sort()
        cvar = np.mean(fval_list[:ak])

        return cvar
    

    def GS_update(self, val0, val1, val2, eps=1e-32):
        z0, z1, z3 = val0, val1, val2
        z2 = z1 + z3 - z0
        dr = eps * (z0 == z2)
        r = (z1 - z3) / ((z0 - z2) + dr)
        dw = np.arctan(float(r))
        dw += np.pi/2 + np.pi/2 * np.sign((z0 - z2) + dr)
        return dw


    def run(self, 
            objective:callable, 
            encode:callable = None,
            search:callable = None,
            op_trans:callable = None, 
            qc_params_init = None, 
            alpha = 1.0,
            max_epoch = 2, 
            random_update = True, 
            refval = None,
            intermediate_result_display = False
            ):

        self.objective = objective
        self.encode = encode
        self.search = search
        self.op_trans = op_trans
        self.alpha = alpha
        
        n_params = len(self.ansatz.parameters)
        if qc_params_init is None:
            self.theta = np.random.uniform(low=0, high=2*np.pi, size=n_params)
        else:
            self.theta = qc_params_init

        self.log = []
        self.elog = []
        self.plog = []
        self.final_epoch = 0
        self.final_step = 0

        self.x = np.zeros(self.num_qubits, dtype=int)
        self.fval = float('inf')
        self.indval = None
        self.refval = refval
        
        isbreak = False
        for _ in range(max_epoch):
            if isbreak: break

            if random_update==True:
                idx_set = np.random.permutation(n_params).astype(int)
            else:
                idx_set = np.arange(n_params).astype(int)

            for j, k in enumerate(idx_set):
                expval = self.calc_expectation(self.theta)

                self.elog.append(expval)
                self.plog.append(self.sprob)
                
                if self.indval is None:
                    objval = self.fval
                else:
                    objval = self.indval
                
                if intermediate_result_display:
                    if self.indval is None:
                        print(f'epoch = {_} \t step = {j} \t objval = {objval:.3f} \t cvar = {expval:.3f}   \t s-prob = {self.sprob:.3e}')
                    else:
                        ind = list(map(round, objval, [3]*len(objval)))
                        print(f'epoch = {_} \t step = {j} \t indicator = {ind}')

                val0 = expval
                self.log.append(objval)

                theta_1 = np.copy(self.theta)
                theta_1[k] += 2*np.pi/3
                val1 = self.calc_expectation(theta_1)

                theta_2 = np.copy(self.theta)
                theta_2[k] -= 2*np.pi/3
                val2 = self.calc_expectation(theta_2)
                
                self.theta[k] += self.GS_update(val0, val1, val2)