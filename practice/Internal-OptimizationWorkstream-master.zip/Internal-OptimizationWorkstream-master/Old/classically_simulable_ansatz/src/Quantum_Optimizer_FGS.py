import numpy as np


class Quantum_Optimizer_FGS():

    def __init__(self) -> None:
        pass


    def set_optimizer(self, num_binary_var, ansatz, sampler):
        self.N = num_binary_var
        self.ansatz = ansatz
        self.sampler = sampler


    def calc_expectation(self, theta, objective:callable, op_trans:callable):
        qc = self.ansatz.bind_parameters(theta)
        qc.measure_all()
        job = self.sampler.run(qc)
        result = job.result()
        quasi_dist = result.quasi_dists[0]
        prob_dict = quasi_dist.binary_probabilities()
        bin_list = list(prob_dict.keys())

        expectation_val = 0
        for bin in bin_list:
            x = np.array(list(bin)).astype(int)
            x = np.flip(x)
            obj_val = objective(x)
            expectation_val += prob_dict[bin] * op_trans(obj_val)

            if obj_val < self.best_fval:
                self.best_fval = obj_val
                self.best_x = x

        return expectation_val
    

    def NFT_update(self, val0, val1, val2, eps=1e-32):
        z0, z1, z3 = val0, val1, val2
        z2 = z1 + z3 - z0
        dr = eps * (z0 == z2)
        r = (z1 - z3) / ((z0 - z2) + dr)
        dw = np.arctan(float(r))
        dw += np.pi/2 + np.pi/2 * np.sign((z0 - z2) + dr)
        return dw


    def get_min_eigval(self, objective:callable, mu, num_sample):
        expectation_val = 0
        for _ in range(num_sample):
            x = np.random.randint(low=0, high=2, size=self.N, dtype=int)
            expectation_val += np.exp(-mu * objective(x))
        
        lam_0 = -np.log(expectation_val) / mu
        return lam_0


    def run(self, objective:callable, op_trans:callable, qc_params_init, max_epoch=10, random_update=True, intermediate_result_display=False, refval=None):
        n_params = len(self.ansatz.parameters)
        theta = qc_params_init

        fval_log = []
        final_epoch = 0
        final_step = 0

        self.best_fval = 1e100
        self.best_x = None

        expval = self.calc_expectation(theta, objective, op_trans)
        
        isbreak = False
        for _ in range(max_epoch):
            if isbreak: break

            if random_update==True:
                idx_set = np.random.permutation(n_params).astype(int)
            else:
                idx_set = np.arange(n_params).astype(int)

            for j, k in enumerate(idx_set):
                if j==0: pass
                else:
                    expval = self.calc_expectation(theta, objective, op_trans)
                
                if intermediate_result_display:
                    print(f'epoch = {_} \t step = {j} \t best val = {self.best_fval:.3f}')

                if not refval is None:
                    if np.isclose(self.best_fval, refval):
                        final_epoch = _
                        final_step = j
                        isbreak = True
                        break

                val0 = expval
                fval_log.append(self.best_fval)

                theta_1 = np.copy(theta)
                theta_1[k] += np.pi/2
                val1 = self.calc_expectation(theta_1, objective, op_trans)

                theta_2 = np.copy(theta)
                theta_2[k] -= np.pi/2
                val2 = self.calc_expectation(theta_2, objective, op_trans)
                
                theta[k] += self.NFT_update(val0, val1, val2)

            expval = self.calc_expectation(theta, objective, op_trans)
            fval_log.append(self.best_fval)
        
            if intermediate_result_display:
                print(f'final: \t best val = {self.best_fval:.3f}')
        
        return {
            'theta': theta, 
            'fval_log': fval_log,
            'final_epoch': final_epoch,
            'final_step': final_step,
        }
