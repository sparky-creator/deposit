import numpy as np
from scipy.optimize import minimize


class Quantum_Solver():

    def __init__(self) -> None:
        pass


    def set_optimizer(self, num_binary_var, ansatz, sampler, objective:callable, intermediate_result_display=True):
        self.N = num_binary_var
        self.ansatz = ansatz
        self.sampler = sampler
        self.objective = objective
        self.intermediate_result_display = intermediate_result_display


    def calc_expectation(self, theta):
        qc = self.ansatz.bind_parameters(theta)
        qc.measure_all()
        job = self.sampler.run(qc)
        result = job.result()
        quasi_dist = result.quasi_dists[0]
        prob_dict = quasi_dist.binary_probabilities()
        bin_list = list(prob_dict.keys())

        expectation_val = 0
        for bin in bin_list:
            x = np.array(list(bin)).astype(int)
            x = np.flip(x)
            obj_val = self.objective(x)
            expectation_val += prob_dict[bin] * obj_val

            if obj_val < self.fval:
                self.fval = obj_val
                self.x = x
        
        if self.intermediate_result_display:
            print(f'step = {self.step} \t fval = {self.fval:.3f}')
        
        self.step += 1

        return expectation_val


    def run(self, qc_params_init, maxiter=100):
        
        self.theta = qc_params_init
        self.fset = []
        self.fval = 1e100
        self.x = None
        self.step = 0

        result = minimize(
            fun =       self.calc_expectation,
            x0 =        self.theta,
            method =    'COBYLA',
            options =   {'maxiter':maxiter}
            )
        
        self.theta = result.x