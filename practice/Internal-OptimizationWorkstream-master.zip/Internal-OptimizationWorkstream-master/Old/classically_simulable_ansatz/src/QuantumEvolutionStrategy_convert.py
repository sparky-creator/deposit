import numpy as np
import optuna


class QuantumEvolutionStrategy():

    def __init__(self) -> None:
        pass


    def set_optimizer(self, num_binary_var, ansatz, sampler):
        self.N = num_binary_var
        self.ansatz = ansatz
        self.n_params = ansatz.num_parameters
        self.sampler = sampler


    def run_sampler(self, theta):
        qc = self.ansatz.bind_parameters(theta)
        qc.measure_all()
        job = self.sampler.run(qc)
        result = job.result()
        
        quasi_dist = result.quasi_dists[0]
        self.prob_dict = quasi_dist.binary_probabilities()
        self.bin_list = list(self.prob_dict.keys())
    
    
    def target_func(self, trial, intermediate_result_display):
        y = np.array([trial.suggest_float(f'y({j})', -1, 1) for j in range(self.n_params)])
        self.theta = np.arccos(y)
        #self.theta = [trial.suggest_float(f'theta({j})', 0, 2*np.pi) for j in range(self.n_params)]

        self.run_sampler(self.theta)

        value = float('inf')
        prob = 0
        for bin in self.bin_list:
            z = np.array(list(bin)).astype(int)
            z = np.flip(z)
            x = self.convert_bit_sol(z)

            if not np.allclose(self.equation(x), 0):
                continue

            fval = self.objective(x)
            
            if fval < self.fval:
                self.fval = fval
                self.x = x
            
            if self.prob_dict[bin] > prob:
                value = fval

        objval = self.indicator(self.x)

        if intermediate_result_display == True:
            print(f'step = {self.step} \t objval = {objval:.3f}')

        self.log.append(objval)

        if not self.refval is None:
            if np.isclose(objval, self.refval):
                trial.study.stop()
        
        self.step += 1

        return value


    def run(
        self, 
        objective:callable, equation:callable, indicator:callable,
        convert_bit_sol=lambda x:x,
        x_initial=None,
        maxiter=100, refval=None, 
        intermediate_result_display=True
        ):

        self.objective = objective
        self.equation = equation
        self.indicator = indicator
        self.convert_bit_sol = convert_bit_sol
        self.refval = refval
        self.step = 0
        self.x = np.zeros(self.N, dtype=int)
        self.fval = float('inf')
        self.log = []

        study = optuna.create_study(
            direction = 'minimize', 
            sampler = optuna.samplers.CmaEsSampler(),
            study_name = 'Quantum Optimization'
            )
        
        optuna.logging.disable_default_handler() 

        study.optimize(
            func = lambda trial: self.target_func(trial, intermediate_result_display), 
            n_trials = maxiter
            )